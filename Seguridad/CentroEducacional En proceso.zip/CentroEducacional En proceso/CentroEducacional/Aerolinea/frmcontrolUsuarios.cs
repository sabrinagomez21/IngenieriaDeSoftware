﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Data.Odbc;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Navegador;

namespace Aerolinea
{
    public partial class frmcontrolUsuarios : Form
    {
        public static OdbcCommand _comando;
        public static OdbcDataReader _reader;
        public frmcontrolUsuarios()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void labelUser_Click(object sender, EventArgs e)
        {

        }

        private void frmControlUsuarios_Load(object sender, EventArgs e)
        {
            funLlenarComboPersona();
            funLlenarComboTipoUsuario();
            funconsultarUsuario();


            funllenarComboEliminarUsuario();

            //funbuscarUsuario();
        }

        private void funLlenarComboPersona()
        {



            MessageBox.Show("entrando a llenar combo");
            string squery = "SELECT codigo_persona, nombre FROM ce2016.persona";
            OdbcCommand cmdc = new OdbcCommand(squery, ConexionODBC.Conexion.ObtenerConexion());
            DataTable dtDatos = new DataTable();
            OdbcDataAdapter mdaDatos = new OdbcDataAdapter(squery, ConexionODBC.Conexion.ObtenerConexion());
            mdaDatos.Fill(dtDatos);
            cmbseleccionarpersona.ValueMember = "codigo_persona";
            cmbseleccionarpersona.DisplayMember = "nombre";
            cmbseleccionarpersona.DataSource = dtDatos;

        }
        private void btnGuardarUsuario_Click(object sender, EventArgs e)
        {

            // clasnegocio cn = new clasnegocio();
            //Boolean bPermiso = true;
            //string sTabla = "jornada";
            // TextBox[] a = { txtUser };
            //cn.AsignarObjetos(sTabla, bPermiso, a);

            try
            {
                int ifilas2;
                int iCodigoUsuario2;

                string squery = "SELECT COUNT(*) As Cant FROM centroedu.USUARIO ";
                OdbcCommand cmd = new OdbcCommand(squery, ConexionODBC.Conexion.ObtenerConexion());
                ifilas2 = Convert.ToInt32(cmd.ExecuteScalar());
                iCodigoUsuario2 = ifilas2 + 1;
                MessageBox.Show("pasando consulta COUNT");

                string sInsertarUsuario = "INSERT INTO centroedu.USUARIO  (codigo_usuario, nombre_usuario, password_usuario,estado, codigo_rol, codigopersona )values(" + iCodigoUsuario2 + ",'" + txtUser.Text + "','" + txtPassword.Text + "','" + "ACTIVO" + "','" + cmbSeleccionartipo.SelectedValue + "','" + cmbseleccionarpersona.SelectedValue + "')";
                OdbcCommand cmd2 = new OdbcCommand(sInsertarUsuario, ConexionODBC.Conexion.ObtenerConexion());
                OdbcDataReader MyReader;
                MyReader = cmd2.ExecuteReader();
                MessageBox.Show("USUARIO REGISTRADO");
                //INGRESO BITACORA 
                claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Ingreso Usuario", "USUARIO");
                //FIN iNGRESO bITACORA


                funlimpiar();
                //funconsultarUsuario();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void funlimpiar()
        {
            txtUser.Text = "";
            txtPassword.Text = "";
        }
        private void dataGridViewUsuarios_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void funconsultarUsuario()
        {

            string squery = "SELECT codigo_usuario as CodigoUsuario, nombre_usuario as NombreUsuario, apellido as ApellidoUsuario, user as Usuario, password_usuario as Password, codigo_rol as TipoUsuario, estado as Estado from centroedu.USUARIO where estado = 'ACTIVO'";
            OdbcCommand cmdc = new OdbcCommand(squery, ConexionODBC.Conexion.ObtenerConexion());
            DataTable dtDatos = new DataTable();
            OdbcDataAdapter mdaDatos = new OdbcDataAdapter(squery, ConexionODBC.Conexion.ObtenerConexion());
            mdaDatos.Fill(dtDatos);
            grdUsuarios.DataSource = dtDatos;


        }
        private void funLlenarComboTipoUsuario()
        {


            string squery = "SELECT codigo_rol, tipo FROM centroedu.ROL";
            OdbcCommand cmdc = new OdbcCommand(squery, ConexionODBC.Conexion.ObtenerConexion());
            DataTable dtDatos = new DataTable();
            OdbcDataAdapter mdaDatos = new OdbcDataAdapter(squery, ConexionODBC.Conexion.ObtenerConexion());
            mdaDatos.Fill(dtDatos);
            cmbSeleccionartipo.ValueMember = "codigo_rol";
            cmbSeleccionartipo.DisplayMember = "tipo";
            cmbSeleccionartipo.DataSource = dtDatos;


        }
        private void funbuscarUsuario()
        {


            string squeryBuscarUsuario = "SELECT codigo_persona as CodigoUsuario, nombre_usuario as NombreUsuario,apellido as ApellidoUsuario, user as Usuario,password_usuario as Password, codigo_rol as TipoUsuario,estado as EstadoUsuario FROM centroedu.USUARIO  where nombre_usuario='" + txtbusquedaUsuario.Text + "'";
            OdbcCommand cmdc = new OdbcCommand(squeryBuscarUsuario, ConexionODBC.Conexion.ObtenerConexion());
            DataTable dtDat = new DataTable();
            OdbcDataAdapter mdaDat = new OdbcDataAdapter(squeryBuscarUsuario, ConexionODBC.Conexion.ObtenerConexion());
            mdaDat.Fill(dtDat);
            grdUsuarios.DataSource = dtDat;
            //INGRESO A BITACORA
            claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Busco Usuario", "MaUsuario");
            //FIN INGRESO BITACORA



        }
        private void funllenarComboEliminarUsuario()
        {

            string squery = "SELECT codigo_persona, user FROM ce2016.USUARIO where estado='ACTIVO'";
            OdbcCommand cmdc = new OdbcCommand(squery, ConexionODBC.Conexion.ObtenerConexion());
            DataTable dtDatos = new DataTable();
            OdbcDataAdapter mdaDatos = new OdbcDataAdapter(squery, ConexionODBC.Conexion.ObtenerConexion());
            mdaDatos.Fill(dtDatos);
            cmbeliminarUsuario.ValueMember = "codigo_persona";
            cmbeliminarUsuario.DisplayMember = "user";
            cmbeliminarUsuario.DataSource = dtDatos;


        }
        private void funeliminarUsuario()
        {
            try
            {
                //string sfechaNacimiento = dtpasajero.Value.ToShortDateString();
                //MessageBox.Show(sfechaNacimiento);
                string seliminarUsuario = "UPDATE centroedu.USUARIO set estado = 'INACTIVO' where codigo_persona = '" + cmbeliminarUsuario.SelectedValue + "'";
                OdbcCommand cmd2 = new OdbcCommand(seliminarUsuario, ConexionODBC.Conexion.ObtenerConexion());
                cmd2.ExecuteNonQuery();
                //INGRESO BITACORA
                claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Elimino Usuario", "Usuario");
                //FIN INGRESO BITACORA

                funconsultarUsuario();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void cmbSeleccionartipo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnBuscarUsuario_Click(object sender, EventArgs e)
        {
            funbuscarUsuario();
        }

        private void btnEliminarUsuario_Click(object sender, EventArgs e)
        {
            funeliminarUsuario();
            funllenarComboEliminarUsuario();
        }

        private void sALIRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            frmLogin back = new frmLogin();
            back.Show();
        }

        private void btnModificarUsuario_Click(object sender, EventArgs e)
        {
            this.Close();
            frmmodificarUsuario modificar = new frmmodificarUsuario();
            modificar.Show();
        }
        private void rEFRESCARToolStripMenuItem_Click(object sender, EventArgs e)
        {
            funconsultarUsuario();
            funllenarComboEliminarUsuario();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
          
          
            String sql = "SELECT permiso FROM privilegios WHERE codigo_rol = " + 1 + "'";
            try
            {
                OdbcDataAdapter sqlDa = new OdbcDataAdapter(sql, ConexionODBC.Conexion.ObtenerConexion());
                DataTable permisos = new DataTable("permiso");
                sqlDa.Fill(permisos);
                if (permisos.Rows.Count == 1)
                {
                    MessageBox.Show("asignando permisos");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("error");
            }
        }
    }
}


    