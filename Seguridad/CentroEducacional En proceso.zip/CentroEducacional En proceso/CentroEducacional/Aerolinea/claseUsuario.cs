﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Odbc;
using ConexionODBC;

namespace Aerolinea
{
    class claseUsuario
    {
        public static string varibaleUsuario;
        public static OdbcCommand _comando;
        public static OdbcDataReader _reader;

        public static Boolean Autentificar(String txtUsuario, String txtContra)
        {
            Boolean Encontre = false;
            _comando = new OdbcCommand(String.Format("select * from USUARIO where nombre_usuario = '{0}' and password_usuario = '{1}' and estado = 'ACTIVO'", txtUsuario, txtContra), ConexionODBC.Conexion.ObtenerConexion());
            _reader = _comando.ExecuteReader();
            if (_reader.Read())
                Encontre = true;
            return Encontre;
        }

        public static String user(String txtUsuario, String txtContra)
        {
            String total = "";
            _comando = new OdbcCommand(String.Format("select USUARIO.nombre_usuario , ROL.tipo from USUARIO inner join ROL on ROL.codigo_rol = USUARIO.codigo_usuario where nombre_usuario = '{0}' and password_usuario = '{1}'", txtUsuario, txtContra), ConexionODBC.Conexion.ObtenerConexion());
            _reader = _comando.ExecuteReader();
            if(_reader.Read())
                total = _reader.GetString(1);
            return total;
        }
        public static void funobtenerBitacora(String txtUsuario, String Accion, String table)
        {
            string codigo  = "";
            _comando = new OdbcCommand(String.Format("select codigo_usuario from USUARIO where nombre_usuario = '{0}'", txtUsuario), ConexionODBC.Conexion.ObtenerConexion());
            _reader = _comando.ExecuteReader();
            if (_reader.Read())
                codigo = _reader.GetString(0);

            _comando = new OdbcCommand(String.Format("INSERT INTO BITACORA (accion, tabla, fecha, codigo_usuario) VALUES('{0}','{1}',CURDATE(),'{2}')",Accion, table, codigo), ConexionODBC.Conexion.ObtenerConexion());
            _reader = _comando.ExecuteReader();
        }

    }
}
