﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Navegador;
using ConexionODBC;
using System.Data.Odbc;

namespace Aerolinea
{
    public partial class frmcontrolUsuarios : Form
    {
        public frmcontrolUsuarios()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
        
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void labelUser_Click(object sender, EventArgs e)
        {

        }
        private void funLlenarComboPersona()
        {
            MessageBox.Show("entrando a llenar combo");
            string squery = "SELECT codigo_persona, nombre FROM ce2016.persona";
            OdbcCommand cmdc = new OdbcCommand(squery, ConexionODBC.Conexion.ObtenerConexion());
            DataTable dtDatos = new DataTable();
            OdbcDataAdapter mdaDatos = new OdbcDataAdapter(squery, ConexionODBC.Conexion.ObtenerConexion());
            mdaDatos.Fill(dtDatos);
            cmbseleccionarpersona.ValueMember = "codigo_persona";
            cmbseleccionarpersona.DisplayMember = "nombre";
            cmbseleccionarpersona.DataSource = dtDatos;

        }
        private void frmControlUsuarios_Load(object sender, EventArgs e)
        {
            //funconsultarUsuario();
            funLlenarComboTipoUsuario();
            funLlenarComboPersona();
            funllenarComboEliminarUsuario();
            funLlenarComboPersona();
            //funbuscarUsuario();
        }
    private void btnGuardarUsuario_Click(object sender, EventArgs e)
        {
            // clasnegocio cn = new clasnegocio();
            //Boolean bPermiso = true;
            //string sTabla = "jornada";
            // TextBox[] a = { txtUser };
            //cn.AsignarObjetos(sTabla, bPermiso, a);

            try
            {
                int ifilas2;
                int iCodigoUsuario2;

                string squery = "SELECT COUNT(*) As Cant FROM centroedu.USUARIO ";
                OdbcCommand cmd = new OdbcCommand(squery, ConexionODBC.Conexion.ObtenerConexion());
                ifilas2 = Convert.ToInt32(cmd.ExecuteScalar());
                iCodigoUsuario2 = ifilas2 + 1;
                MessageBox.Show("pasando consulta COUNT");

                string sInsertarUsuario = "INSERT INTO centroedu.USUARIO  (codigo_usuario, nombre_usuario, password_usuario,estado, codigo_rol, codigopersona )values(" + iCodigoUsuario2 + ",'" + txtUser.Text + "','" + txtPassword.Text + "','" + "ACTIVO" + "','" + cmbSeleccionartipo.SelectedValue + "','" + cmbseleccionarpersona.SelectedValue + "')";
                OdbcCommand cmd2 = new OdbcCommand(sInsertarUsuario, ConexionODBC.Conexion.ObtenerConexion());
                OdbcDataReader MyReader;
                MyReader = cmd2.ExecuteReader();
                MessageBox.Show("USUARIO REGISTRADO");
                //INGRESO BITACORA 
                claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Ingreso Usuario", "USUARIO");
                //FIN iNGRESO bITACORA


                funlimpiar();
                //funconsultarUsuario();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void funlimpiar()
        {
            
            txtUser.Text = "";
            txtPassword.Text = "";
        }
        private void dataGridViewUsuarios_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void funconsultarUsuario()
        {

            string squeryBuscarUsuario = "SELECT codigo_persona as CodigoUsuario, nombre_usuario as NombreUsuario, user as Usuario,password_usuario as Password, codigo_rol as TipoUsuario,estado as EstadoUsuario FROM centroedu.USUARIO  where nombre_usuario='" + txtbusquedaUsuario.Text + "'";
            OdbcCommand cmdc = new OdbcCommand(squeryBuscarUsuario, ConexionODBC.Conexion.ObtenerConexion());
            DataTable dtDat = new DataTable();
            OdbcDataAdapter mdaDat = new OdbcDataAdapter(squeryBuscarUsuario, ConexionODBC.Conexion.ObtenerConexion());
            mdaDat.Fill(dtDat);
            grdUsuarios.DataSource = dtDat;
            //INGRESO A BITACORA
            claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Busco Usuario", "MaUsuario");
            //FIN INGRESO BITACORA


        }
        private void funLlenarComboTipoUsuario() {
            string squery = "SELECT codigo_rol, tipo FROM centroedu.ROL";
            OdbcCommand cmdc = new OdbcCommand(squery, ConexionODBC.Conexion.ObtenerConexion());
            DataTable dtDatos = new DataTable();
            OdbcDataAdapter mdaDatos = new OdbcDataAdapter(squery, ConexionODBC.Conexion.ObtenerConexion());
            mdaDatos.Fill(dtDatos);
            cmbSeleccionartipo.ValueMember = "codigo_rol";
            cmbSeleccionartipo.DisplayMember = "tipo";
            cmbSeleccionartipo.DataSource = dtDatos;
        }
        private void funbuscarUsuario()
        {

            string squeryBuscarUsuario = "SELECT codigopersona as CodigoUsuario, nombre_usuario as NombreUsuario, nombre_usuario as Usuario,password_usuario as Password, codigo_rol as TipoUsuario,estado as EstadoUsuario FROM centroedu.USUARIO  where nombre_usuario='" + txtbusquedaUsuario.Text + "'";
            OdbcCommand cmdc = new OdbcCommand(squeryBuscarUsuario, ConexionODBC.Conexion.ObtenerConexion());
            DataTable dtDat = new DataTable();
            OdbcDataAdapter mdaDat = new OdbcDataAdapter(squeryBuscarUsuario, ConexionODBC.Conexion.ObtenerConexion());
            mdaDat.Fill(dtDat);
            grdUsuarios.DataSource = dtDat;
            //INGRESO A BITACORA
            claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Busco Usuario", "MaUsuario");
            //FIN INGRESO BITACORA


        }
        private void funllenarComboEliminarUsuario()
        {
            /*using (clasconexion.funobtenerConexion())
            {
                string squery = "SELECT codigo_persona, user FROM ce2016.USUARIO where estado='ACTIVO'";
                MySqlCommand cmdc = new MySqlCommand(squery, clasconexion.funobtenerConexion());
                DataTable dtDatos = new DataTable();
                MySqlDataAdapter mdaDatos = new MySqlDataAdapter(squery, clasconexion.funobtenerConexion());
                mdaDatos.Fill(dtDatos);
                cmbeliminarUsuario.ValueMember = "codigo_persona";
                cmbeliminarUsuario.DisplayMember = "user";
                cmbeliminarUsuario.DataSource = dtDatos;
                clasconexion.funobtenerConexion().Close();
            }*/
        }
        private void funeliminarUsuario()
        {
            /*using (clasconexion.funobtenerConexion())
            {
                try
                {
                    //string sfechaNacimiento = dtpasajero.Value.ToShortDateString();
                    //MessageBox.Show(sfechaNacimiento);
                    string seliminarUsuario = "UPDATE ce2016.USUARIO set estado = 'INACTIVO' where codigo_persona = '" + cmbeliminarUsuario.SelectedValue + "'"; 
                    MySqlCommand cmd2 = new MySqlCommand(seliminarUsuario, clasconexion.funobtenerConexion());
                    cmd2.ExecuteNonQuery();
                    //INGRESO BITACORA
                    claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Elimino Usuario", "Usuario");
                    //FIN INGRESO BITACORA
                    clasconexion.funobtenerConexion().Close();
                    funconsultarUsuario();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }*/
        }
 
        private void cmbSeleccionartipo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnBuscarUsuario_Click(object sender, EventArgs e)
        {
            funbuscarUsuario();
        }

        private void btnEliminarUsuario_Click(object sender, EventArgs e)
        {
            funeliminarUsuario();
            funllenarComboEliminarUsuario();
        }

        private void sALIRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnModificarUsuario_Click(object sender, EventArgs e)
        {
            this.Close();
            frmmodificarUsuario modificar = new frmmodificarUsuario();
            modificar.Show();
        }
        private void rEFRESCARToolStripMenuItem_Click(object sender, EventArgs e)
        {
            funconsultarUsuario();
            funllenarComboEliminarUsuario();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
    