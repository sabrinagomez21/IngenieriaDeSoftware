﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Navegador;

namespace Aerolinea
{
    public partial class frmTipoPago : Form
    {
        string estado = "";
        string sCod;
        public frmTipoPago()
        {
            InitializeComponent();
            btnGuardar.Enabled = false;
            btnCancelar.Enabled = false;
            btnImprimir.Enabled = false;
            funActualizarGrid();
        }

        private void funActualizarGrid()
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funconsultarRegistros("tipo_pago", "SELECT cod_tipo_pago as Codigo, Descripcion as Descripcion, Cuotas as Cuotas, estado as Estado from tipo_pago WHERE estado = 'ACTIVO'", "consulta", grdPago);
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funactivarDesactivarTextbox(txtDescripcion, true);
            cnegocio.funactivarDesactivarTextbox(txtCuotas, true);
            btnGuardar.Enabled = true;
            btnCancelar.Enabled = true;
            btnNuevo.Enabled = false;
            btnEditar.Enabled = false;
            btnEliminar.Enabled = false;
            btnRefrescar.Enabled = false;
            btnBuscar.Enabled = false;
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            estado = "editar";
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funactivarDesactivarTextbox(txtDescripcion, true);
            cnegocio.funactivarDesactivarTextbox(txtCuotas, true);
            //txtNombre.Clear();
            btnGuardar.Enabled = true;
            btnCancelar.Enabled = true;
            btnNuevo.Enabled = false;
            btnEditar.Enabled = false;
            btnEliminar.Enabled = false;
            btnRefrescar.Enabled = false;
            btnBuscar.Enabled = false;
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            estado = "eliminar";
            clasnegocio cn = new clasnegocio();
            cn.funactivarDesactivarTextbox(txtDescripcion, false);
            cn.funactivarDesactivarTextbox(txtCuotas, false);
            btnGuardar.Enabled = true;
            btnCancelar.Enabled = true;
            btnNuevo.Enabled = false;
            btnEditar.Enabled = false;
            btnEliminar.Enabled = false;
            btnRefrescar.Enabled = false;
            btnBuscar.Enabled = false;
            btnAnterior.Enabled = false;
            btnIrPrimero.Enabled = false;
            btnSiguiente.Enabled = false;
            btnIrUltimo.Enabled = false;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            clasnegocio cn = new clasnegocio();
            Boolean bPermiso = true;

            if (estado.Equals("editar"))
            {

                TextBox[] aDatosEdit = { txtDescripcion, txtCuotas };
                string sTabla = "tipo_pago";
                string sCodigo = "cod_tipo_pago";

                cn.EditarObjetos(sTabla, bPermiso, aDatosEdit, sCod, sCodigo);
                claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Editar", sTabla);


            }
            else if (estado.Equals("eliminar"))
            {
                string sTabla = "tipo_pago";
                string sCampoLlavePrimaria = "cod_tipo_pago";
                string sCampoEstado = "estado";
                //System.Console.WriteLine("----" + sCod);
                cn.funeliminarRegistro(sTabla, sCod, sCampoLlavePrimaria, sCampoEstado);
                claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Eliminar", sTabla);
            }
            else if (estado.Equals(""))
            {
                TextBox[] aDatos = { txtDescripcion, txtCuotas, txtEstado };
                string sTabla = "tipo_pago";
                cn.AsignarObjetos(sTabla, bPermiso, aDatos);
                claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Insertar", sTabla);
            }

            estado = "";
            txtDescripcion.Clear();
            txtCuotas.Clear();
            cn.funactivarDesactivarTextbox(txtDescripcion, false);
            cn.funactivarDesactivarTextbox(txtCuotas, false);
            btnGuardar.Enabled = false;
            btnCancelar.Enabled = false;
            btnImprimir.Enabled = false;
            btnNuevo.Enabled = true;
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
            btnRefrescar.Enabled = true;
            btnBuscar.Enabled = true;
            btnAnterior.Enabled = true;
            btnIrPrimero.Enabled = true;
            btnSiguiente.Enabled = true;
            btnIrUltimo.Enabled = true;
            funActualizarGrid();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            clasnegocio cn = new clasnegocio();
            cn.funactivarDesactivarTextbox(txtDescripcion, false);
            cn.funactivarDesactivarTextbox(txtCuotas, false);
            txtBuscar.Visible = false;
            lblBuscar.Visible = false;
            lblDescripcion.Visible = true;
            txtDescripcion.Visible = true;
            lblCuotas.Visible = true;
            txtCuotas.Visible = true;
            txtDescripcion.Clear();
            txtCuotas.Clear();
            txtBuscar.Clear();


            btnGuardar.Enabled = false;
            btnCancelar.Enabled = false;
            btnImprimir.Enabled = false;
            btnNuevo.Enabled = true;
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
            btnRefrescar.Enabled = true;
            btnBuscar.Enabled = true;
            btnAnterior.Enabled = true;
            btnIrPrimero.Enabled = true;
            btnSiguiente.Enabled = true;
            btnIrUltimo.Enabled = true;
        }

        private void btnRefrescar_Click(object sender, EventArgs e)
        {
            funActualizarGrid();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            txtDescripcion.Visible = false;
            lblDescripcion.Visible = false;
            txtCuotas.Visible = false;
            lblCuotas.Visible = false;
            txtBuscar.Visible = true;
            lblBuscar.Visible = true;

            btnGuardar.Enabled = false;
            btnCancelar.Enabled = true;
            btnNuevo.Enabled = false;
            btnEditar.Enabled = false;
            btnEliminar.Enabled = false;
            btnRefrescar.Enabled = false;
            btnBuscar.Enabled = false;
            claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Busqueda", "tipo_pago");
        }

        private void txtBuscar_KeyUp(object sender, KeyEventArgs e)
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funconsultarRegistros("tipo_pago", "SELECT cod_tipo_pago as Codigo, Descripcion as Descripcion, Cuotas as Cuotas, estado as Estado from tipo_pago WHERE estado = 'ACTIVO' AND descripcion LIKE '" + txtBuscar.Text + "%'", "consulta", grdPago);
        }

        private void grdPago_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (estado.Equals("editar"))
            {
                clasnegocio cn = new clasnegocio();
                cn.funactivarDesactivarTextbox(txtDescripcion, true);
                sCod = grdPago.Rows[grdPago.CurrentCell.RowIndex].Cells[0].Value.ToString();
                txtDescripcion.Text = grdPago.Rows[grdPago.CurrentCell.RowIndex].Cells[1].Value.ToString();
                txtCuotas.Text = grdPago.Rows[grdPago.CurrentCell.RowIndex].Cells[2].Value.ToString();


            } if (estado.Equals("eliminar"))
            {
                sCod = grdPago.Rows[grdPago.CurrentCell.RowIndex].Cells[0].Value.ToString();
            }
        }

        private void btnIrPrimero_Click(object sender, EventArgs e)
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funPrimero(grdPago);
        }

        private void btnAnterior_Click(object sender, EventArgs e)
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funAnterior(grdPago);
        }

        private void btnSiguiente_Click(object sender, EventArgs e)
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funSiguiente(grdPago);
        }

        private void btnIrUltimo_Click(object sender, EventArgs e)
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funUltimo(grdPago);
        }

        private void frmTipoPago_Load(object sender, EventArgs e)
        {

        }
    }
}
