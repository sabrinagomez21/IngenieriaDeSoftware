﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aerolinea
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (claseUsuario.Autentificar(txtUser.Text, txtPass.Text) == true)
            {
                //VALIDACIÓN DE USUARIO ADMINISTRADOR
                if (claseUsuario.user(txtUser.Text, txtPass.Text).Equals("Admin"))
                {

                    string Mensaje = "Desea crear un nuevo usuario?";
                    string caption = "Ingreso";
                    MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                    DialogResult result;

                    // Displays the MessageBox.

                    result = MessageBox.Show(Mensaje, caption, buttons);

                    if (result == System.Windows.Forms.DialogResult.Yes)
                    {


                        this.Hide();
                        frmcontrolUsuarios Control = new frmcontrolUsuarios();
                        Control.Show();

                    }
                    else
                    {
                        this.Hide();
                        frmMenu Menu = new frmMenu();
                        Menu.Show();
                        Menu.toolStripStatusLabel2.Text = "Usuario: " + txtUser.Text;
                        Menu.toolStripStatusLabel.Text = DateTime.Now.ToString();

                        claseUsuario.varibaleUsuario = txtUser.Text;
                        claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Ingreso al Sistema", "Administrador");
                        MessageBox.Show("Bienvenid@:  " + claseUsuario.user(txtUser.Text, txtPass.Text) + ":" + claseUsuario.varibaleUsuario);
                    }
                }

                //VALIDACIÓN DE USUARIO NORMAL (PERMISOS BÁSICOS DE INSERTAR Y CONSULTAR)
                else if (claseUsuario.user(txtUser.Text, txtPass.Text).Equals("Catedra"))
                {
                    this.Hide();
                    frmMenu MenuNormal = new frmMenu();
                    MenuNormal.Show();
                    MenuNormal.toolStripStatusLabel2.Text = "Usuario: " + txtUser.Text;

                    //MenuNormal.uSUARIOSToolStripMenuItem.Enabled = false;
                    // MenuNormal.rEPORTESToolStripMenuItem.Enabled = false;
                    // MenuNormal.toolStripStatusLabel.Text = DateTime.Now.ToString();*/
                    claseUsuario.varibaleUsuario = txtUser.Text;
                    claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Ingreso al Sistema", "Catedra");
                    MessageBox.Show("Bienvenid@:  " + claseUsuario.user(txtUser.Text, txtPass.Text) + ":" + claseUsuario.varibaleUsuario);






                }

                //VALIDACIÓN USUARIO QUE ACCEDE A INFORMACIÓN DE VUELOS
                else if (claseUsuario.user(txtUser.Text, txtPass.Text).Equals("Alumno"))
                {
                    this.Hide();
                    frmMenu MenuVuelos = new frmMenu();
                    MenuVuelos.Show();
                    MenuVuelos.toolStripStatusLabel2.Text = "Usuario: " + txtUser.Text;
                    // MenuVuelos.uSUARIOSToolStripMenuItem.Enabled = false;

                    //MenuVuelos.rEPORTESToolStripMenuItem.Enabled = false;
                    //MenuVuelos.toolStripStatusLabel.Text = DateTime.Now.ToString();*/
                    claseUsuario.varibaleUsuario = txtUser.Text;
                    claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Ingreso al Sistema", "Alumno");
                    MessageBox.Show("Bienvenid@:  " + claseUsuario.user(txtUser.Text, txtPass.Text) + ":" + claseUsuario.varibaleUsuario);
                }

            }
            else
                MessageBox.Show("Usuario o contraseña no valido, si el problema persiste su usuario esta INACTIVO", "Acceso Invalido", MessageBoxButtons.OK, MessageBoxIcon.Error);


            txtUser.Clear();
            txtPass.Clear();
        }
    }
}
