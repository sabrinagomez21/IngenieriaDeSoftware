﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//PROGRAMADOR Y ANALISTA: Pamela Jacqueline Selman David

namespace Aerolinea
{
    public partial class frmMenu : Form
    {
        public frmMenu()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void cERRARSESSIONToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult resul = MessageBox.Show("Esta seguro que desea cerrar session?", "Mensage de Confirmacion", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (resul == System.Windows.Forms.DialogResult.OK)
            {
                this.Close();
                frmLogin login = new frmLogin();
                login.Show();  
            }
        }

        
        private void aYUDAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Help.ShowHelp(this, "file://C:\\Aerolínea.chm");
        }

        private void bitacoraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            frmbitacora temp = new frmbitacora();
            temp.Show();
        }

        private void creacionUsuariosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            frmcontrolUsuarios temp = new frmcontrolUsuarios();
            temp.Show();
        }

        private void facultadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            frmFacultad temp = new frmFacultad();
            temp.Show();
        }

        private void salonesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            frmSalones temp = new frmSalones();
            temp.Show();
        }

        private void sedesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            frmSedes temp = new frmSedes();
            temp.Show();
        }

        private void tipoPagoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            frmTipoPago temp = new frmTipoPago();
            temp.Show();
        }

        private void tipoServicioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            frmTipoServicio temp = new frmTipoServicio();
            temp.Show();
        }
    }
}
