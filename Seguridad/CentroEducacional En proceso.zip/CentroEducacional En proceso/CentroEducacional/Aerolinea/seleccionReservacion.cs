﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aerolinea
{
    public partial class seleccionReservacion : Form
    {
        public seleccionReservacion()
        {
            InitializeComponent();
        }

        private void btnA2_Click(object sender, EventArgs e)
        {
            btnA2.BackColor = Color.Red;

        }

        private void btnA3_Click(object sender, EventArgs e)
        {
            btnA3.BackColor = Color.Red;

        }
        private void btnA4_Click(object sender, EventArgs e)
        {
            btnA4.BackColor = Color.Red;

        }
        private void btnA5_Click(object sender, EventArgs e)
        {
            btnA5.BackColor = Color.Red;

        }
        private void btnA6_Click(object sender, EventArgs e)
        {
            btnA6.BackColor = Color.Red;

        }
        private void btnA7_Click(object sender, EventArgs e)
        {
            btnA7.BackColor = Color.Red;

        }
        private void btnA8_Click(object sender, EventArgs e)
        {
            btnA8.BackColor = Color.Red;

        }
        private void btnA9_Click(object sender, EventArgs e)
        {
            btnA9.BackColor = Color.Red;

        }
        private void btnA10_Click(object sender, EventArgs e)
        {
            btnA10.BackColor = Color.Red;

        }
        private void btnA11_Click(object sender, EventArgs e)
        {
            btnA11.BackColor = Color.Red;

        }
        private void btnA12_Click(object sender, EventArgs e)
        {
            btnA12.BackColor = Color.Red;

        }
        private void btnA13_Click(object sender, EventArgs e)
        {
            btnA13.BackColor = Color.Red;

        }
        private void btnA14_Click(object sender, EventArgs e)
        {
            btnA14.BackColor = Color.Red;

        }
        private void btnA15_Click(object sender, EventArgs e)
        {
            btnA15.BackColor = Color.Red;

        }
        private void btnB1_Click(object sender, EventArgs e)
        {
            btnB1.BackColor = Color.Red;

        }
        private void btnB2_Click(object sender, EventArgs e)
        {
            btnB2.BackColor = Color.Red;

        }
        private void btnB3_Click(object sender, EventArgs e)
        {
            btnB3.BackColor = Color.Red;

        }
        private void btnB4_Click(object sender, EventArgs e)
        {
            btnB4.BackColor = Color.Red;

        }
        private void btnB5_Click(object sender, EventArgs e)
        {
            btnB5.BackColor = Color.Red;

        }
        private void btnB6_Click(object sender, EventArgs e)
        {
            btnB6.BackColor = Color.Red;

        }
        private void btnB7_Click(object sender, EventArgs e)
        {
            btnB7.BackColor = Color.Red;

        }
        private void btnB8_Click(object sender, EventArgs e)
        {
            btnB8.BackColor = Color.Red;

        }
        private void btnB9_Click(object sender, EventArgs e)
        {
            btnB9.BackColor = Color.Red;

        }
        private void btnB10_Click(object sender, EventArgs e)
        {
            btnB10.BackColor = Color.Red;

        }
        private void btnB11_Click(object sender, EventArgs e)
        {
            btnB11.BackColor = Color.Red;

        }
        private void btnB12_Click(object sender, EventArgs e)
        {
            btnB12.BackColor = Color.Red;

        }
        private void btnB13_Click(object sender, EventArgs e)
        {
            btnB13.BackColor = Color.Red;

        }
        private void btnB14_Click(object sender, EventArgs e)
        {
            btnB14.BackColor = Color.Red;

        }
        private void btnB15_Click(object sender, EventArgs e)
        {
            btnB15.BackColor = Color.Red;

        }
        private void btnC1_Click(object sender, EventArgs e)
        {
            btnC1.BackColor = Color.Red;

        }
        private void btnC2_Click(object sender, EventArgs e)
        {
            btnC2.BackColor = Color.Red;

        }
        private void btnC3_Click(object sender, EventArgs e)
        {
            btnC3.BackColor = Color.Red;

        }
        private void btnC4_Click(object sender, EventArgs e)
        {
            btnC4.BackColor = Color.Red;

        }
        private void btnC5_Click(object sender, EventArgs e)
        {
            btnC5.BackColor = Color.Red;

        }
        private void btnC6_Click(object sender, EventArgs e)
        {
            btnC6.BackColor = Color.Red;

        }
        private void btnC7_Click(object sender, EventArgs e)
        {
            btnC7.BackColor = Color.Red;

        }
        private void btnC8_Click(object sender, EventArgs e)
        {
            btnC8.BackColor = Color.Red;

        }
        private void btnC9_Click(object sender, EventArgs e)
        {
            btnC9.BackColor = Color.Red;

        }
        private void btnC10_Click(object sender, EventArgs e)
        {
            btnC10.BackColor = Color.Red;

        }
        private void btnC11_Click(object sender, EventArgs e)
        {
            btnC11.BackColor = Color.Red;

        }
        private void btnC12_Click(object sender, EventArgs e)
        {
            btnC12.BackColor = Color.Red;

        }
        private void btnC13_Click(object sender, EventArgs e)
        {
            btnC13.BackColor = Color.Red;

        }
        private void btnC14_Click(object sender, EventArgs e)
        {
            btnC14.BackColor = Color.Red;

        }
        private void btnC15_Click(object sender, EventArgs e)
        {
            btnC15.BackColor = Color.Red;

        }
        private void btnD1_Click(object sender, EventArgs e)
        {
            btnD1.BackColor = Color.Red;

        }
        private void btnD2_Click(object sender, EventArgs e)
        {
            btnD2.BackColor = Color.Red;

        }
        private void btnD3_Click(object sender, EventArgs e)
        {
            btnD3.BackColor = Color.Red;

        }
        private void btnD4_Click(object sender, EventArgs e)
        {
            btnD4.BackColor = Color.Red;

        }
        private void btnD5_Click(object sender, EventArgs e)
        {
            btnD5.BackColor = Color.Red;

        }
        private void btnD6_Click(object sender, EventArgs e)
        {
            btnD6.BackColor = Color.Red;

        }
        private void btnD7_Click(object sender, EventArgs e)
        {
            btnD7.BackColor = Color.Red;

        }
        private void btnD8_Click(object sender, EventArgs e)
        {
            btnD8.BackColor = Color.Red;

        }
        private void btnD9_Click(object sender, EventArgs e)
        {
            btnD9.BackColor = Color.Red;

        }
        private void btnD10_Click(object sender, EventArgs e)
        {
            btnD10.BackColor = Color.Red;

        }
        private void btnD11_Click(object sender, EventArgs e)
        {
            btnD11.BackColor = Color.Red;

        }
        private void btnD12_Click(object sender, EventArgs e)
        {
            btnD12.BackColor = Color.Red;

        }
        private void btnD13_Click(object sender, EventArgs e)
        {
            btnD13.BackColor = Color.Red;

        }
        private void btnD14_Click(object sender, EventArgs e)
        {
            btnD14.BackColor = Color.Red;

        }
        private void btnD15_Click(object sender, EventArgs e)
        {
            btnD15.BackColor = Color.Red;

        }
        private void btnE1_Click(object sender, EventArgs e)
        {
            btnE1.BackColor = Color.Red;

        }
        private void btnE2_Click(object sender, EventArgs e)
        {
            btnE2.BackColor = Color.Red;

        }
        private void btnE3_Click(object sender, EventArgs e)
        {
            btnE3.BackColor = Color.Red;

        }
        private void btnE4_Click(object sender, EventArgs e)
        {
            btnE4.BackColor = Color.Red;

        }
        private void btnE5_Click(object sender, EventArgs e)
        {
            btnE5.BackColor = Color.Red;

        }
        private void btnE6_Click(object sender, EventArgs e)
        {
            btnE6.BackColor = Color.Red;

        }
        private void btnE7_Click(object sender, EventArgs e)
        {
            btnE7.BackColor = Color.Red;

        }
        private void btnE8_Click(object sender, EventArgs e)
        {
            btnE8.BackColor = Color.Red;

        }
        private void btnE9_Click(object sender, EventArgs e)
        {
            btnE9.BackColor = Color.Red;

        }
        private void btnE10_Click(object sender, EventArgs e)
        {
            btnE10.BackColor = Color.Red;

        }
        private void btnE11_Click(object sender, EventArgs e)
        {
            btnE11.BackColor = Color.Red;

        }
        private void btnE12_Click(object sender, EventArgs e)
        {
            btnE12.BackColor = Color.Red;

        }
        private void btnE13_Click(object sender, EventArgs e)
        {
            btnE13.BackColor = Color.Red;

        }
        private void btnE14_Click(object sender, EventArgs e)
        {
            btnE14.BackColor = Color.Red;

        }
        private void btnE15_Click(object sender, EventArgs e)
        {
            btnE15.BackColor = Color.Red;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            realizacionPago fmp = new realizacionPago();
            fmp.Show();
        }

    }
}
