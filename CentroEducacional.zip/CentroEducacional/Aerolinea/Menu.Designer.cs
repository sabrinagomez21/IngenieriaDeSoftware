﻿namespace Aerolinea
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.pASAJEROSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eliminarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modificarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vUELOSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registroToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.eliminarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.modificarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.rESERVACIONESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registroToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.cancelaciónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modificaciónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pAGOSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aYUDAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rEPORTESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasajerosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.vuelosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.reservacionesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.pagosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pASAJEROSToolStripMenuItem,
            this.vUELOSToolStripMenuItem,
            this.rESERVACIONESToolStripMenuItem,
            this.pAGOSToolStripMenuItem,
            this.aYUDAToolStripMenuItem,
            this.rEPORTESToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1014, 27);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // pASAJEROSToolStripMenuItem
            // 
            this.pASAJEROSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.registroToolStripMenuItem,
            this.eliminarToolStripMenuItem,
            this.modificarToolStripMenuItem});
            this.pASAJEROSToolStripMenuItem.Font = new System.Drawing.Font("Calibri", 12F);
            this.pASAJEROSToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("pASAJEROSToolStripMenuItem.Image")));
            this.pASAJEROSToolStripMenuItem.Name = "pASAJEROSToolStripMenuItem";
            this.pASAJEROSToolStripMenuItem.Size = new System.Drawing.Size(109, 23);
            this.pASAJEROSToolStripMenuItem.Text = "PASAJEROS";
            this.pASAJEROSToolStripMenuItem.Click += new System.EventHandler(this.pASAJEROSToolStripMenuItem_Click);
            // 
            // registroToolStripMenuItem
            // 
            this.registroToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("registroToolStripMenuItem.Image")));
            this.registroToolStripMenuItem.Name = "registroToolStripMenuItem";
            this.registroToolStripMenuItem.Size = new System.Drawing.Size(199, 24);
            this.registroToolStripMenuItem.Text = "Registrar Pasajero";
            this.registroToolStripMenuItem.Click += new System.EventHandler(this.registroToolStripMenuItem_Click);
            // 
            // eliminarToolStripMenuItem
            // 
            this.eliminarToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("eliminarToolStripMenuItem.Image")));
            this.eliminarToolStripMenuItem.Name = "eliminarToolStripMenuItem";
            this.eliminarToolStripMenuItem.Size = new System.Drawing.Size(199, 24);
            this.eliminarToolStripMenuItem.Text = "Eliminar Pasajero";
            // 
            // modificarToolStripMenuItem
            // 
            this.modificarToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("modificarToolStripMenuItem.Image")));
            this.modificarToolStripMenuItem.Name = "modificarToolStripMenuItem";
            this.modificarToolStripMenuItem.Size = new System.Drawing.Size(199, 24);
            this.modificarToolStripMenuItem.Text = "Modificar Pasajero";
            // 
            // vUELOSToolStripMenuItem
            // 
            this.vUELOSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.registroToolStripMenuItem1,
            this.eliminarToolStripMenuItem1,
            this.modificarToolStripMenuItem1});
            this.vUELOSToolStripMenuItem.Font = new System.Drawing.Font("Calibri", 12F);
            this.vUELOSToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("vUELOSToolStripMenuItem.Image")));
            this.vUELOSToolStripMenuItem.Name = "vUELOSToolStripMenuItem";
            this.vUELOSToolStripMenuItem.Size = new System.Drawing.Size(89, 23);
            this.vUELOSToolStripMenuItem.Text = "VUELOS";
            // 
            // registroToolStripMenuItem1
            // 
            this.registroToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("registroToolStripMenuItem1.Image")));
            this.registroToolStripMenuItem1.Name = "registroToolStripMenuItem1";
            this.registroToolStripMenuItem1.Size = new System.Drawing.Size(180, 24);
            this.registroToolStripMenuItem1.Text = "Registro Vuelo";
            this.registroToolStripMenuItem1.Click += new System.EventHandler(this.registroToolStripMenuItem1_Click);
            // 
            // eliminarToolStripMenuItem1
            // 
            this.eliminarToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("eliminarToolStripMenuItem1.Image")));
            this.eliminarToolStripMenuItem1.Name = "eliminarToolStripMenuItem1";
            this.eliminarToolStripMenuItem1.Size = new System.Drawing.Size(180, 24);
            this.eliminarToolStripMenuItem1.Text = "Eliminar Vuelo";
            this.eliminarToolStripMenuItem1.Click += new System.EventHandler(this.eliminarToolStripMenuItem1_Click);
            // 
            // modificarToolStripMenuItem1
            // 
            this.modificarToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("modificarToolStripMenuItem1.Image")));
            this.modificarToolStripMenuItem1.Name = "modificarToolStripMenuItem1";
            this.modificarToolStripMenuItem1.Size = new System.Drawing.Size(180, 24);
            this.modificarToolStripMenuItem1.Text = "Modificar Vuelo";
            this.modificarToolStripMenuItem1.Click += new System.EventHandler(this.modificarToolStripMenuItem1_Click);
            // 
            // rESERVACIONESToolStripMenuItem
            // 
            this.rESERVACIONESToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.registroToolStripMenuItem2,
            this.cancelaciónToolStripMenuItem,
            this.modificaciónToolStripMenuItem});
            this.rESERVACIONESToolStripMenuItem.Font = new System.Drawing.Font("Calibri", 12F);
            this.rESERVACIONESToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("rESERVACIONESToolStripMenuItem.Image")));
            this.rESERVACIONESToolStripMenuItem.Name = "rESERVACIONESToolStripMenuItem";
            this.rESERVACIONESToolStripMenuItem.Size = new System.Drawing.Size(144, 23);
            this.rESERVACIONESToolStripMenuItem.Text = "RESERVACIONES";
            this.rESERVACIONESToolStripMenuItem.Click += new System.EventHandler(this.rESERVACIONESToolStripMenuItem_Click);
            // 
            // registroToolStripMenuItem2
            // 
            this.registroToolStripMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("registroToolStripMenuItem2.Image")));
            this.registroToolStripMenuItem2.Name = "registroToolStripMenuItem2";
            this.registroToolStripMenuItem2.Size = new System.Drawing.Size(244, 24);
            this.registroToolStripMenuItem2.Text = "Registro Reservación";
            this.registroToolStripMenuItem2.Click += new System.EventHandler(this.registroToolStripMenuItem2_Click);
            // 
            // cancelaciónToolStripMenuItem
            // 
            this.cancelaciónToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("cancelaciónToolStripMenuItem.Image")));
            this.cancelaciónToolStripMenuItem.Name = "cancelaciónToolStripMenuItem";
            this.cancelaciónToolStripMenuItem.Size = new System.Drawing.Size(244, 24);
            this.cancelaciónToolStripMenuItem.Text = "Cancelación Reservación";
            this.cancelaciónToolStripMenuItem.Click += new System.EventHandler(this.cancelaciónToolStripMenuItem_Click);
            // 
            // modificaciónToolStripMenuItem
            // 
            this.modificaciónToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("modificaciónToolStripMenuItem.Image")));
            this.modificaciónToolStripMenuItem.Name = "modificaciónToolStripMenuItem";
            this.modificaciónToolStripMenuItem.Size = new System.Drawing.Size(244, 24);
            this.modificaciónToolStripMenuItem.Text = "Modificación Reservación";
            // 
            // pAGOSToolStripMenuItem
            // 
            this.pAGOSToolStripMenuItem.Font = new System.Drawing.Font("Calibri", 12F);
            this.pAGOSToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("pAGOSToolStripMenuItem.Image")));
            this.pAGOSToolStripMenuItem.Name = "pAGOSToolStripMenuItem";
            this.pAGOSToolStripMenuItem.Size = new System.Drawing.Size(81, 23);
            this.pAGOSToolStripMenuItem.Text = "PAGOS";
            this.pAGOSToolStripMenuItem.Click += new System.EventHandler(this.pAGOSToolStripMenuItem_Click);
            // 
            // aYUDAToolStripMenuItem
            // 
            this.aYUDAToolStripMenuItem.Font = new System.Drawing.Font("Calibri", 12F);
            this.aYUDAToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("aYUDAToolStripMenuItem.Image")));
            this.aYUDAToolStripMenuItem.Name = "aYUDAToolStripMenuItem";
            this.aYUDAToolStripMenuItem.Size = new System.Drawing.Size(82, 23);
            this.aYUDAToolStripMenuItem.Text = "AYUDA";
            this.aYUDAToolStripMenuItem.Click += new System.EventHandler(this.aYUDAToolStripMenuItem_Click);
            // 
            // rEPORTESToolStripMenuItem
            // 
            this.rEPORTESToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pasajerosToolStripMenuItem1,
            this.vuelosToolStripMenuItem1,
            this.reservacionesToolStripMenuItem1,
            this.pagosToolStripMenuItem1});
            this.rEPORTESToolStripMenuItem.Font = new System.Drawing.Font("Calibri", 12F);
            this.rEPORTESToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("rEPORTESToolStripMenuItem.Image")));
            this.rEPORTESToolStripMenuItem.Name = "rEPORTESToolStripMenuItem";
            this.rEPORTESToolStripMenuItem.Size = new System.Drawing.Size(105, 23);
            this.rEPORTESToolStripMenuItem.Text = "REPORTES";
            // 
            // pasajerosToolStripMenuItem1
            // 
            this.pasajerosToolStripMenuItem1.Name = "pasajerosToolStripMenuItem1";
            this.pasajerosToolStripMenuItem1.Size = new System.Drawing.Size(172, 24);
            this.pasajerosToolStripMenuItem1.Text = "Pasajeros";
            // 
            // vuelosToolStripMenuItem1
            // 
            this.vuelosToolStripMenuItem1.Name = "vuelosToolStripMenuItem1";
            this.vuelosToolStripMenuItem1.Size = new System.Drawing.Size(172, 24);
            this.vuelosToolStripMenuItem1.Text = "Vuelos";
            // 
            // reservacionesToolStripMenuItem1
            // 
            this.reservacionesToolStripMenuItem1.Name = "reservacionesToolStripMenuItem1";
            this.reservacionesToolStripMenuItem1.Size = new System.Drawing.Size(172, 24);
            this.reservacionesToolStripMenuItem1.Text = "Reservaciones";
            // 
            // pagosToolStripMenuItem1
            // 
            this.pagosToolStripMenuItem1.Name = "pagosToolStripMenuItem1";
            this.pagosToolStripMenuItem1.Size = new System.Drawing.Size(172, 24);
            this.pagosToolStripMenuItem1.Text = "Pagos";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::Aerolinea.Properties.Resources.ga;
            this.pictureBox1.Location = new System.Drawing.Point(0, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1014, 607);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleTurquoise;
            this.ClientSize = new System.Drawing.Size(1014, 634);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu Principal";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form2_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem pASAJEROSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rESERVACIONESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pAGOSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aYUDAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rEPORTESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vUELOSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eliminarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modificarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registroToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem eliminarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem modificarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem registroToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem cancelaciónToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modificaciónToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasajerosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem vuelosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem reservacionesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem pagosToolStripMenuItem1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}