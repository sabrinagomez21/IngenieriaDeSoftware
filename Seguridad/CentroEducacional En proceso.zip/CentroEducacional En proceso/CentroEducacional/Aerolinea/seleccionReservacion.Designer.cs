﻿namespace Aerolinea
{
    partial class seleccionReservacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(seleccionReservacion));
            this.btnA2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnA3 = new System.Windows.Forms.Button();
            this.btnA4 = new System.Windows.Forms.Button();
            this.btnA5 = new System.Windows.Forms.Button();
            this.btnA6 = new System.Windows.Forms.Button();
            this.btnA7 = new System.Windows.Forms.Button();
            this.btnA8 = new System.Windows.Forms.Button();
            this.btnA9 = new System.Windows.Forms.Button();
            this.btnA10 = new System.Windows.Forms.Button();
            this.btnA11 = new System.Windows.Forms.Button();
            this.btnA12 = new System.Windows.Forms.Button();
            this.btnA13 = new System.Windows.Forms.Button();
            this.btnA14 = new System.Windows.Forms.Button();
            this.btnA15 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btnB1 = new System.Windows.Forms.Button();
            this.btnB2 = new System.Windows.Forms.Button();
            this.btnB3 = new System.Windows.Forms.Button();
            this.btnB4 = new System.Windows.Forms.Button();
            this.btnB5 = new System.Windows.Forms.Button();
            this.btnB6 = new System.Windows.Forms.Button();
            this.btnB7 = new System.Windows.Forms.Button();
            this.btnB8 = new System.Windows.Forms.Button();
            this.btnB9 = new System.Windows.Forms.Button();
            this.btnB10 = new System.Windows.Forms.Button();
            this.btnB11 = new System.Windows.Forms.Button();
            this.btnB12 = new System.Windows.Forms.Button();
            this.btnB13 = new System.Windows.Forms.Button();
            this.btnB14 = new System.Windows.Forms.Button();
            this.btnB15 = new System.Windows.Forms.Button();
            this.btnC1 = new System.Windows.Forms.Button();
            this.btnC2 = new System.Windows.Forms.Button();
            this.btnC3 = new System.Windows.Forms.Button();
            this.btnC4 = new System.Windows.Forms.Button();
            this.btnC5 = new System.Windows.Forms.Button();
            this.btnC6 = new System.Windows.Forms.Button();
            this.btnC7 = new System.Windows.Forms.Button();
            this.btnC8 = new System.Windows.Forms.Button();
            this.btnC9 = new System.Windows.Forms.Button();
            this.btnC10 = new System.Windows.Forms.Button();
            this.btnC11 = new System.Windows.Forms.Button();
            this.btnC12 = new System.Windows.Forms.Button();
            this.btnC13 = new System.Windows.Forms.Button();
            this.btnC14 = new System.Windows.Forms.Button();
            this.btnC15 = new System.Windows.Forms.Button();
            this.btnD1 = new System.Windows.Forms.Button();
            this.btnD2 = new System.Windows.Forms.Button();
            this.btnD3 = new System.Windows.Forms.Button();
            this.btnD4 = new System.Windows.Forms.Button();
            this.btnD5 = new System.Windows.Forms.Button();
            this.btnD6 = new System.Windows.Forms.Button();
            this.btnD7 = new System.Windows.Forms.Button();
            this.btnD8 = new System.Windows.Forms.Button();
            this.btnD9 = new System.Windows.Forms.Button();
            this.btnD10 = new System.Windows.Forms.Button();
            this.btnD11 = new System.Windows.Forms.Button();
            this.btnD12 = new System.Windows.Forms.Button();
            this.btnD13 = new System.Windows.Forms.Button();
            this.btnD14 = new System.Windows.Forms.Button();
            this.btnD15 = new System.Windows.Forms.Button();
            this.btnE1 = new System.Windows.Forms.Button();
            this.btnE2 = new System.Windows.Forms.Button();
            this.btnE3 = new System.Windows.Forms.Button();
            this.btnE4 = new System.Windows.Forms.Button();
            this.btnE5 = new System.Windows.Forms.Button();
            this.btnE6 = new System.Windows.Forms.Button();
            this.btnE7 = new System.Windows.Forms.Button();
            this.btnE8 = new System.Windows.Forms.Button();
            this.btnE9 = new System.Windows.Forms.Button();
            this.btnE10 = new System.Windows.Forms.Button();
            this.btnE11 = new System.Windows.Forms.Button();
            this.btnE12 = new System.Windows.Forms.Button();
            this.btnE13 = new System.Windows.Forms.Button();
            this.btnE14 = new System.Windows.Forms.Button();
            this.btnE15 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnRegresar = new System.Windows.Forms.Button();
            this.btnReservar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnA2
            // 
            this.btnA2.BackColor = System.Drawing.Color.Lime;
            this.btnA2.Location = new System.Drawing.Point(939, 206);
            this.btnA2.Name = "btnA2";
            this.btnA2.Size = new System.Drawing.Size(28, 19);
            this.btnA2.TabIndex = 0;
            this.btnA2.Text = "A2";
            this.btnA2.UseVisualStyleBackColor = false;
            this.btnA2.Click += new System.EventHandler(this.btnA2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(524, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(254, 23);
            this.label1.TabIndex = 1;
            this.label1.Text = "Seleccione el Asiento a Reservar";
            // 
            // btnA3
            // 
            this.btnA3.BackColor = System.Drawing.Color.Lime;
            this.btnA3.Location = new System.Drawing.Point(890, 206);
            this.btnA3.Name = "btnA3";
            this.btnA3.Size = new System.Drawing.Size(28, 19);
            this.btnA3.TabIndex = 2;
            this.btnA3.Text = "A3";
            this.btnA3.UseVisualStyleBackColor = false;
            this.btnA3.Click += new System.EventHandler(this.btnA3_Click);
            // 
            // btnA4
            // 
            this.btnA4.BackColor = System.Drawing.Color.Lime;
            this.btnA4.Location = new System.Drawing.Point(843, 206);
            this.btnA4.Name = "btnA4";
            this.btnA4.Size = new System.Drawing.Size(28, 19);
            this.btnA4.TabIndex = 3;
            this.btnA4.Text = "A4";
            this.btnA4.UseVisualStyleBackColor = false;
            this.btnA4.Click += new System.EventHandler(this.btnA4_Click);
            // 
            // btnA5
            // 
            this.btnA5.BackColor = System.Drawing.Color.Lime;
            this.btnA5.Location = new System.Drawing.Point(794, 206);
            this.btnA5.Name = "btnA5";
            this.btnA5.Size = new System.Drawing.Size(28, 19);
            this.btnA5.TabIndex = 4;
            this.btnA5.Text = "A5";
            this.btnA5.UseVisualStyleBackColor = false;
            this.btnA5.Click += new System.EventHandler(this.btnA5_Click);
            // 
            // btnA6
            // 
            this.btnA6.BackColor = System.Drawing.Color.Lime;
            this.btnA6.Location = new System.Drawing.Point(748, 206);
            this.btnA6.Name = "btnA6";
            this.btnA6.Size = new System.Drawing.Size(28, 19);
            this.btnA6.TabIndex = 5;
            this.btnA6.Text = "A6";
            this.btnA6.UseVisualStyleBackColor = false;
            this.btnA6.Click += new System.EventHandler(this.btnA6_Click);
            // 
            // btnA7
            // 
            this.btnA7.BackColor = System.Drawing.Color.Lime;
            this.btnA7.Location = new System.Drawing.Point(701, 206);
            this.btnA7.Name = "btnA7";
            this.btnA7.Size = new System.Drawing.Size(28, 19);
            this.btnA7.TabIndex = 6;
            this.btnA7.Text = "A7";
            this.btnA7.UseVisualStyleBackColor = false;
            this.btnA7.Click += new System.EventHandler(this.btnA7_Click);
            // 
            // btnA8
            // 
            this.btnA8.BackColor = System.Drawing.Color.Lime;
            this.btnA8.Location = new System.Drawing.Point(655, 206);
            this.btnA8.Name = "btnA8";
            this.btnA8.Size = new System.Drawing.Size(28, 19);
            this.btnA8.TabIndex = 7;
            this.btnA8.Text = "A8";
            this.btnA8.UseVisualStyleBackColor = false;
            this.btnA8.Click += new System.EventHandler(this.btnA8_Click);
            // 
            // btnA9
            // 
            this.btnA9.BackColor = System.Drawing.Color.Lime;
            this.btnA9.Location = new System.Drawing.Point(607, 206);
            this.btnA9.Name = "btnA9";
            this.btnA9.Size = new System.Drawing.Size(28, 19);
            this.btnA9.TabIndex = 8;
            this.btnA9.Text = "A9";
            this.btnA9.UseVisualStyleBackColor = false;
            this.btnA9.Click += new System.EventHandler(this.btnA9_Click);
            // 
            // btnA10
            // 
            this.btnA10.BackColor = System.Drawing.Color.Lime;
            this.btnA10.Location = new System.Drawing.Point(556, 206);
            this.btnA10.Name = "btnA10";
            this.btnA10.Size = new System.Drawing.Size(35, 19);
            this.btnA10.TabIndex = 9;
            this.btnA10.Text = "A10";
            this.btnA10.UseVisualStyleBackColor = false;
            this.btnA10.Click += new System.EventHandler(this.btnA10_Click);
            // 
            // btnA11
            // 
            this.btnA11.BackColor = System.Drawing.Color.Lime;
            this.btnA11.Location = new System.Drawing.Point(510, 206);
            this.btnA11.Name = "btnA11";
            this.btnA11.Size = new System.Drawing.Size(40, 19);
            this.btnA11.TabIndex = 10;
            this.btnA11.Text = "A11";
            this.btnA11.UseVisualStyleBackColor = false;
            this.btnA11.Click += new System.EventHandler(this.btnA11_Click);
            // 
            // btnA12
            // 
            this.btnA12.BackColor = System.Drawing.Color.Lime;
            this.btnA12.Location = new System.Drawing.Point(467, 206);
            this.btnA12.Name = "btnA12";
            this.btnA12.Size = new System.Drawing.Size(37, 19);
            this.btnA12.TabIndex = 11;
            this.btnA12.Text = "A12";
            this.btnA12.UseVisualStyleBackColor = false;
            this.btnA12.Click += new System.EventHandler(this.btnA12_Click);
            // 
            // btnA13
            // 
            this.btnA13.BackColor = System.Drawing.Color.Lime;
            this.btnA13.Location = new System.Drawing.Point(421, 206);
            this.btnA13.Name = "btnA13";
            this.btnA13.Size = new System.Drawing.Size(40, 19);
            this.btnA13.TabIndex = 12;
            this.btnA13.Text = "A13";
            this.btnA13.UseVisualStyleBackColor = false;
            this.btnA13.Click += new System.EventHandler(this.btnA13_Click);
            // 
            // btnA14
            // 
            this.btnA14.BackColor = System.Drawing.Color.Lime;
            this.btnA14.Location = new System.Drawing.Point(376, 206);
            this.btnA14.Name = "btnA14";
            this.btnA14.Size = new System.Drawing.Size(39, 19);
            this.btnA14.TabIndex = 13;
            this.btnA14.Text = "A14";
            this.btnA14.UseVisualStyleBackColor = false;
            this.btnA14.Click += new System.EventHandler(this.btnA14_Click);
            // 
            // btnA15
            // 
            this.btnA15.BackColor = System.Drawing.Color.Lime;
            this.btnA15.Location = new System.Drawing.Point(328, 206);
            this.btnA15.Name = "btnA15";
            this.btnA15.Size = new System.Drawing.Size(34, 19);
            this.btnA15.TabIndex = 14;
            this.btnA15.Text = "A15";
            this.btnA15.UseVisualStyleBackColor = false;
            this.btnA15.Click += new System.EventHandler(this.btnA15_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(26, 205);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(240, 19);
            this.label2.TabIndex = 15;
            this.label2.Text = "*De la fila 1 a la 4 es Primera Clase";
            // 
            // btnB1
            // 
            this.btnB1.BackColor = System.Drawing.Color.Lime;
            this.btnB1.Location = new System.Drawing.Point(984, 249);
            this.btnB1.Name = "btnB1";
            this.btnB1.Size = new System.Drawing.Size(28, 19);
            this.btnB1.TabIndex = 16;
            this.btnB1.Text = "B1";
            this.btnB1.UseVisualStyleBackColor = false;
            this.btnB1.Click += new System.EventHandler(this.btnB1_Click);
            // 
            // btnB2
            // 
            this.btnB2.BackColor = System.Drawing.Color.Lime;
            this.btnB2.Location = new System.Drawing.Point(939, 249);
            this.btnB2.Name = "btnB2";
            this.btnB2.Size = new System.Drawing.Size(28, 19);
            this.btnB2.TabIndex = 17;
            this.btnB2.Text = "B2";
            this.btnB2.UseVisualStyleBackColor = false;
            this.btnB2.Click += new System.EventHandler(this.btnB2_Click);
            // 
            // btnB3
            // 
            this.btnB3.BackColor = System.Drawing.Color.Lime;
            this.btnB3.Location = new System.Drawing.Point(890, 249);
            this.btnB3.Name = "btnB3";
            this.btnB3.Size = new System.Drawing.Size(28, 19);
            this.btnB3.TabIndex = 18;
            this.btnB3.Text = "B3";
            this.btnB3.UseVisualStyleBackColor = false;
            this.btnB3.Click += new System.EventHandler(this.btnB3_Click);
            // 
            // btnB4
            // 
            this.btnB4.BackColor = System.Drawing.Color.Lime;
            this.btnB4.Location = new System.Drawing.Point(843, 249);
            this.btnB4.Name = "btnB4";
            this.btnB4.Size = new System.Drawing.Size(28, 19);
            this.btnB4.TabIndex = 19;
            this.btnB4.Text = "B4";
            this.btnB4.UseVisualStyleBackColor = false;
            this.btnB4.Click += new System.EventHandler(this.btnB4_Click);
            // 
            // btnB5
            // 
            this.btnB5.BackColor = System.Drawing.Color.Lime;
            this.btnB5.Location = new System.Drawing.Point(794, 249);
            this.btnB5.Name = "btnB5";
            this.btnB5.Size = new System.Drawing.Size(28, 19);
            this.btnB5.TabIndex = 20;
            this.btnB5.Text = "B5";
            this.btnB5.UseVisualStyleBackColor = false;
            this.btnB5.Click += new System.EventHandler(this.btnB5_Click);
            // 
            // btnB6
            // 
            this.btnB6.BackColor = System.Drawing.Color.Lime;
            this.btnB6.Location = new System.Drawing.Point(748, 249);
            this.btnB6.Name = "btnB6";
            this.btnB6.Size = new System.Drawing.Size(28, 19);
            this.btnB6.TabIndex = 21;
            this.btnB6.Text = "B6";
            this.btnB6.UseVisualStyleBackColor = false;
            this.btnB6.Click += new System.EventHandler(this.btnB6_Click);
            // 
            // btnB7
            // 
            this.btnB7.BackColor = System.Drawing.Color.Lime;
            this.btnB7.Location = new System.Drawing.Point(701, 249);
            this.btnB7.Name = "btnB7";
            this.btnB7.Size = new System.Drawing.Size(28, 19);
            this.btnB7.TabIndex = 22;
            this.btnB7.Text = "B7";
            this.btnB7.UseVisualStyleBackColor = false;
            this.btnB7.Click += new System.EventHandler(this.btnB7_Click);
            // 
            // btnB8
            // 
            this.btnB8.BackColor = System.Drawing.Color.Lime;
            this.btnB8.Location = new System.Drawing.Point(655, 249);
            this.btnB8.Name = "btnB8";
            this.btnB8.Size = new System.Drawing.Size(28, 19);
            this.btnB8.TabIndex = 23;
            this.btnB8.Text = "B8";
            this.btnB8.UseVisualStyleBackColor = false;
            this.btnB8.Click += new System.EventHandler(this.btnB8_Click);
            // 
            // btnB9
            // 
            this.btnB9.BackColor = System.Drawing.Color.Lime;
            this.btnB9.Location = new System.Drawing.Point(607, 249);
            this.btnB9.Name = "btnB9";
            this.btnB9.Size = new System.Drawing.Size(28, 19);
            this.btnB9.TabIndex = 24;
            this.btnB9.Text = "B9";
            this.btnB9.UseVisualStyleBackColor = false;
            this.btnB9.Click += new System.EventHandler(this.btnB9_Click);
            // 
            // btnB10
            // 
            this.btnB10.BackColor = System.Drawing.Color.Lime;
            this.btnB10.Location = new System.Drawing.Point(556, 249);
            this.btnB10.Name = "btnB10";
            this.btnB10.Size = new System.Drawing.Size(35, 19);
            this.btnB10.TabIndex = 25;
            this.btnB10.Text = "B10";
            this.btnB10.UseVisualStyleBackColor = false;
            this.btnB10.Click += new System.EventHandler(this.btnB10_Click);
            // 
            // btnB11
            // 
            this.btnB11.BackColor = System.Drawing.Color.Lime;
            this.btnB11.Location = new System.Drawing.Point(510, 249);
            this.btnB11.Name = "btnB11";
            this.btnB11.Size = new System.Drawing.Size(40, 19);
            this.btnB11.TabIndex = 26;
            this.btnB11.Text = "B11";
            this.btnB11.UseVisualStyleBackColor = false;
            this.btnB11.Click += new System.EventHandler(this.btnB11_Click);
            // 
            // btnB12
            // 
            this.btnB12.BackColor = System.Drawing.Color.Lime;
            this.btnB12.Location = new System.Drawing.Point(467, 249);
            this.btnB12.Name = "btnB12";
            this.btnB12.Size = new System.Drawing.Size(37, 19);
            this.btnB12.TabIndex = 27;
            this.btnB12.Text = "B12";
            this.btnB12.UseVisualStyleBackColor = false;
            this.btnB12.Click += new System.EventHandler(this.btnB12_Click);
            // 
            // btnB13
            // 
            this.btnB13.BackColor = System.Drawing.Color.Lime;
            this.btnB13.Location = new System.Drawing.Point(421, 249);
            this.btnB13.Name = "btnB13";
            this.btnB13.Size = new System.Drawing.Size(40, 19);
            this.btnB13.TabIndex = 28;
            this.btnB13.Text = "B13";
            this.btnB13.UseVisualStyleBackColor = false;
            this.btnB13.Click += new System.EventHandler(this.btnB13_Click);
            // 
            // btnB14
            // 
            this.btnB14.BackColor = System.Drawing.Color.Lime;
            this.btnB14.Location = new System.Drawing.Point(376, 249);
            this.btnB14.Name = "btnB14";
            this.btnB14.Size = new System.Drawing.Size(39, 19);
            this.btnB14.TabIndex = 29;
            this.btnB14.Text = "B14";
            this.btnB14.UseVisualStyleBackColor = false;
            this.btnB14.Click += new System.EventHandler(this.btnB14_Click);
            // 
            // btnB15
            // 
            this.btnB15.BackColor = System.Drawing.Color.Lime;
            this.btnB15.Location = new System.Drawing.Point(328, 249);
            this.btnB15.Name = "btnB15";
            this.btnB15.Size = new System.Drawing.Size(34, 19);
            this.btnB15.TabIndex = 30;
            this.btnB15.Text = "B15";
            this.btnB15.UseVisualStyleBackColor = false;
            this.btnB15.Click += new System.EventHandler(this.btnB15_Click);
            // 
            // btnC1
            // 
            this.btnC1.BackColor = System.Drawing.Color.Lime;
            this.btnC1.Location = new System.Drawing.Point(984, 294);
            this.btnC1.Name = "btnC1";
            this.btnC1.Size = new System.Drawing.Size(28, 19);
            this.btnC1.TabIndex = 31;
            this.btnC1.Text = "C1";
            this.btnC1.UseVisualStyleBackColor = false;
            this.btnC1.Click += new System.EventHandler(this.btnC1_Click);
            // 
            // btnC2
            // 
            this.btnC2.BackColor = System.Drawing.Color.Lime;
            this.btnC2.Location = new System.Drawing.Point(939, 294);
            this.btnC2.Name = "btnC2";
            this.btnC2.Size = new System.Drawing.Size(28, 19);
            this.btnC2.TabIndex = 32;
            this.btnC2.Text = "C2";
            this.btnC2.UseVisualStyleBackColor = false;
            this.btnC2.Click += new System.EventHandler(this.btnC2_Click);
            // 
            // btnC3
            // 
            this.btnC3.BackColor = System.Drawing.Color.Lime;
            this.btnC3.Location = new System.Drawing.Point(890, 294);
            this.btnC3.Name = "btnC3";
            this.btnC3.Size = new System.Drawing.Size(28, 19);
            this.btnC3.TabIndex = 33;
            this.btnC3.Text = "C3";
            this.btnC3.UseVisualStyleBackColor = false;
            this.btnC3.Click += new System.EventHandler(this.btnC3_Click);
            // 
            // btnC4
            // 
            this.btnC4.BackColor = System.Drawing.Color.Lime;
            this.btnC4.Location = new System.Drawing.Point(843, 294);
            this.btnC4.Name = "btnC4";
            this.btnC4.Size = new System.Drawing.Size(28, 19);
            this.btnC4.TabIndex = 34;
            this.btnC4.Text = "C4";
            this.btnC4.UseVisualStyleBackColor = false;
            this.btnC4.Click += new System.EventHandler(this.btnC4_Click);
            // 
            // btnC5
            // 
            this.btnC5.BackColor = System.Drawing.Color.Lime;
            this.btnC5.Location = new System.Drawing.Point(794, 294);
            this.btnC5.Name = "btnC5";
            this.btnC5.Size = new System.Drawing.Size(28, 19);
            this.btnC5.TabIndex = 35;
            this.btnC5.Text = "C5";
            this.btnC5.UseVisualStyleBackColor = false;
            this.btnC5.Click += new System.EventHandler(this.btnC5_Click);
            // 
            // btnC6
            // 
            this.btnC6.BackColor = System.Drawing.Color.Lime;
            this.btnC6.Location = new System.Drawing.Point(748, 294);
            this.btnC6.Name = "btnC6";
            this.btnC6.Size = new System.Drawing.Size(28, 19);
            this.btnC6.TabIndex = 36;
            this.btnC6.Text = "C6";
            this.btnC6.UseVisualStyleBackColor = false;
            this.btnC6.Click += new System.EventHandler(this.btnC6_Click);
            // 
            // btnC7
            // 
            this.btnC7.BackColor = System.Drawing.Color.Lime;
            this.btnC7.Location = new System.Drawing.Point(701, 294);
            this.btnC7.Name = "btnC7";
            this.btnC7.Size = new System.Drawing.Size(28, 19);
            this.btnC7.TabIndex = 37;
            this.btnC7.Text = "C7";
            this.btnC7.UseVisualStyleBackColor = false;
            this.btnC7.Click += new System.EventHandler(this.btnC7_Click);
            // 
            // btnC8
            // 
            this.btnC8.BackColor = System.Drawing.Color.Lime;
            this.btnC8.Location = new System.Drawing.Point(655, 294);
            this.btnC8.Name = "btnC8";
            this.btnC8.Size = new System.Drawing.Size(28, 19);
            this.btnC8.TabIndex = 38;
            this.btnC8.Text = "C8";
            this.btnC8.UseVisualStyleBackColor = false;
            this.btnC8.Click += new System.EventHandler(this.btnC8_Click);
            // 
            // btnC9
            // 
            this.btnC9.BackColor = System.Drawing.Color.Lime;
            this.btnC9.Location = new System.Drawing.Point(607, 294);
            this.btnC9.Name = "btnC9";
            this.btnC9.Size = new System.Drawing.Size(28, 19);
            this.btnC9.TabIndex = 39;
            this.btnC9.Text = "C9";
            this.btnC9.UseVisualStyleBackColor = false;
            this.btnC9.Click += new System.EventHandler(this.btnC9_Click);
            // 
            // btnC10
            // 
            this.btnC10.BackColor = System.Drawing.Color.Lime;
            this.btnC10.Location = new System.Drawing.Point(556, 294);
            this.btnC10.Name = "btnC10";
            this.btnC10.Size = new System.Drawing.Size(35, 19);
            this.btnC10.TabIndex = 40;
            this.btnC10.Text = "C10";
            this.btnC10.UseVisualStyleBackColor = false;
            this.btnC10.Click += new System.EventHandler(this.btnC10_Click);
            // 
            // btnC11
            // 
            this.btnC11.BackColor = System.Drawing.Color.Lime;
            this.btnC11.Location = new System.Drawing.Point(510, 294);
            this.btnC11.Name = "btnC11";
            this.btnC11.Size = new System.Drawing.Size(40, 19);
            this.btnC11.TabIndex = 41;
            this.btnC11.Text = "C11";
            this.btnC11.UseVisualStyleBackColor = false;
            this.btnC11.Click += new System.EventHandler(this.btnC11_Click);
            // 
            // btnC12
            // 
            this.btnC12.BackColor = System.Drawing.Color.Lime;
            this.btnC12.Location = new System.Drawing.Point(467, 294);
            this.btnC12.Name = "btnC12";
            this.btnC12.Size = new System.Drawing.Size(37, 19);
            this.btnC12.TabIndex = 42;
            this.btnC12.Text = "C12";
            this.btnC12.UseVisualStyleBackColor = false;
            this.btnC12.Click += new System.EventHandler(this.btnC12_Click);
            // 
            // btnC13
            // 
            this.btnC13.BackColor = System.Drawing.Color.Lime;
            this.btnC13.Location = new System.Drawing.Point(421, 294);
            this.btnC13.Name = "btnC13";
            this.btnC13.Size = new System.Drawing.Size(40, 19);
            this.btnC13.TabIndex = 43;
            this.btnC13.Text = "C13";
            this.btnC13.UseVisualStyleBackColor = false;
            this.btnC13.Click += new System.EventHandler(this.btnC13_Click);
            // 
            // btnC14
            // 
            this.btnC14.BackColor = System.Drawing.Color.Lime;
            this.btnC14.Location = new System.Drawing.Point(376, 294);
            this.btnC14.Name = "btnC14";
            this.btnC14.Size = new System.Drawing.Size(39, 19);
            this.btnC14.TabIndex = 44;
            this.btnC14.Text = "C14";
            this.btnC14.UseVisualStyleBackColor = false;
            this.btnC14.Click += new System.EventHandler(this.btnC14_Click);
            // 
            // btnC15
            // 
            this.btnC15.BackColor = System.Drawing.Color.Lime;
            this.btnC15.Location = new System.Drawing.Point(328, 294);
            this.btnC15.Name = "btnC15";
            this.btnC15.Size = new System.Drawing.Size(34, 19);
            this.btnC15.TabIndex = 45;
            this.btnC15.Text = "C15";
            this.btnC15.UseVisualStyleBackColor = false;
            this.btnC15.Click += new System.EventHandler(this.btnC15_Click);
            // 
            // btnD1
            // 
            this.btnD1.BackColor = System.Drawing.Color.Lime;
            this.btnD1.Location = new System.Drawing.Point(984, 371);
            this.btnD1.Name = "btnD1";
            this.btnD1.Size = new System.Drawing.Size(30, 19);
            this.btnD1.TabIndex = 46;
            this.btnD1.Text = "D1";
            this.btnD1.UseVisualStyleBackColor = false;
            this.btnD1.Click += new System.EventHandler(this.btnD1_Click);
            // 
            // btnD2
            // 
            this.btnD2.BackColor = System.Drawing.Color.Lime;
            this.btnD2.Location = new System.Drawing.Point(939, 371);
            this.btnD2.Name = "btnD2";
            this.btnD2.Size = new System.Drawing.Size(30, 19);
            this.btnD2.TabIndex = 47;
            this.btnD2.Text = "D2";
            this.btnD2.UseVisualStyleBackColor = false;
            this.btnD2.Click += new System.EventHandler(this.btnD2_Click);
            // 
            // btnD3
            // 
            this.btnD3.BackColor = System.Drawing.Color.Lime;
            this.btnD3.Location = new System.Drawing.Point(890, 371);
            this.btnD3.Name = "btnD3";
            this.btnD3.Size = new System.Drawing.Size(30, 19);
            this.btnD3.TabIndex = 48;
            this.btnD3.Text = "D3";
            this.btnD3.UseVisualStyleBackColor = false;
            this.btnD3.Click += new System.EventHandler(this.btnD3_Click);
            // 
            // btnD4
            // 
            this.btnD4.BackColor = System.Drawing.Color.Lime;
            this.btnD4.Location = new System.Drawing.Point(843, 371);
            this.btnD4.Name = "btnD4";
            this.btnD4.Size = new System.Drawing.Size(30, 19);
            this.btnD4.TabIndex = 49;
            this.btnD4.Text = "D4";
            this.btnD4.UseVisualStyleBackColor = false;
            this.btnD4.Click += new System.EventHandler(this.btnD4_Click);
            // 
            // btnD5
            // 
            this.btnD5.BackColor = System.Drawing.Color.Lime;
            this.btnD5.Location = new System.Drawing.Point(794, 371);
            this.btnD5.Name = "btnD5";
            this.btnD5.Size = new System.Drawing.Size(30, 19);
            this.btnD5.TabIndex = 50;
            this.btnD5.Text = "D5";
            this.btnD5.UseVisualStyleBackColor = false;
            this.btnD5.Click += new System.EventHandler(this.btnD5_Click);
            // 
            // btnD6
            // 
            this.btnD6.BackColor = System.Drawing.Color.Lime;
            this.btnD6.Location = new System.Drawing.Point(748, 371);
            this.btnD6.Name = "btnD6";
            this.btnD6.Size = new System.Drawing.Size(30, 19);
            this.btnD6.TabIndex = 51;
            this.btnD6.Text = "D6";
            this.btnD6.UseVisualStyleBackColor = false;
            this.btnD6.Click += new System.EventHandler(this.btnD6_Click);
            // 
            // btnD7
            // 
            this.btnD7.BackColor = System.Drawing.Color.Lime;
            this.btnD7.Location = new System.Drawing.Point(701, 371);
            this.btnD7.Name = "btnD7";
            this.btnD7.Size = new System.Drawing.Size(30, 19);
            this.btnD7.TabIndex = 52;
            this.btnD7.Text = "D7";
            this.btnD7.UseVisualStyleBackColor = false;
            this.btnD7.Click += new System.EventHandler(this.btnD7_Click);
            // 
            // btnD8
            // 
            this.btnD8.BackColor = System.Drawing.Color.Lime;
            this.btnD8.Location = new System.Drawing.Point(655, 371);
            this.btnD8.Name = "btnD8";
            this.btnD8.Size = new System.Drawing.Size(30, 19);
            this.btnD8.TabIndex = 53;
            this.btnD8.Text = "D8";
            this.btnD8.UseVisualStyleBackColor = false;
            this.btnD8.Click += new System.EventHandler(this.btnD8_Click);
            // 
            // btnD9
            // 
            this.btnD9.BackColor = System.Drawing.Color.Lime;
            this.btnD9.Location = new System.Drawing.Point(607, 371);
            this.btnD9.Name = "btnD9";
            this.btnD9.Size = new System.Drawing.Size(30, 19);
            this.btnD9.TabIndex = 54;
            this.btnD9.Text = "D9";
            this.btnD9.UseVisualStyleBackColor = false;
            this.btnD9.Click += new System.EventHandler(this.btnD9_Click);
            // 
            // btnD10
            // 
            this.btnD10.BackColor = System.Drawing.Color.Lime;
            this.btnD10.Location = new System.Drawing.Point(556, 371);
            this.btnD10.Name = "btnD10";
            this.btnD10.Size = new System.Drawing.Size(35, 19);
            this.btnD10.TabIndex = 55;
            this.btnD10.Text = "D10";
            this.btnD10.UseVisualStyleBackColor = false;
            this.btnD10.Click += new System.EventHandler(this.btnD10_Click);
            // 
            // btnD11
            // 
            this.btnD11.BackColor = System.Drawing.Color.Lime;
            this.btnD11.Location = new System.Drawing.Point(510, 371);
            this.btnD11.Name = "btnD11";
            this.btnD11.Size = new System.Drawing.Size(40, 19);
            this.btnD11.TabIndex = 56;
            this.btnD11.Text = "D11";
            this.btnD11.UseVisualStyleBackColor = false;
            this.btnD11.Click += new System.EventHandler(this.btnD11_Click);
            // 
            // btnD12
            // 
            this.btnD12.BackColor = System.Drawing.Color.Lime;
            this.btnD12.Location = new System.Drawing.Point(467, 371);
            this.btnD12.Name = "btnD12";
            this.btnD12.Size = new System.Drawing.Size(37, 19);
            this.btnD12.TabIndex = 57;
            this.btnD12.Text = "D12";
            this.btnD12.UseVisualStyleBackColor = false;
            this.btnD12.Click += new System.EventHandler(this.btnD12_Click);
            // 
            // btnD13
            // 
            this.btnD13.BackColor = System.Drawing.Color.Lime;
            this.btnD13.Location = new System.Drawing.Point(421, 371);
            this.btnD13.Name = "btnD13";
            this.btnD13.Size = new System.Drawing.Size(40, 19);
            this.btnD13.TabIndex = 58;
            this.btnD13.Text = "D13";
            this.btnD13.UseVisualStyleBackColor = false;
            this.btnD13.Click += new System.EventHandler(this.btnD13_Click);
            // 
            // btnD14
            // 
            this.btnD14.BackColor = System.Drawing.Color.Lime;
            this.btnD14.Location = new System.Drawing.Point(376, 371);
            this.btnD14.Name = "btnD14";
            this.btnD14.Size = new System.Drawing.Size(39, 19);
            this.btnD14.TabIndex = 59;
            this.btnD14.Text = "D14";
            this.btnD14.UseVisualStyleBackColor = false;
            this.btnD14.Click += new System.EventHandler(this.btnD14_Click);
            // 
            // btnD15
            // 
            this.btnD15.BackColor = System.Drawing.Color.Lime;
            this.btnD15.Location = new System.Drawing.Point(320, 371);
            this.btnD15.Name = "btnD15";
            this.btnD15.Size = new System.Drawing.Size(42, 19);
            this.btnD15.TabIndex = 60;
            this.btnD15.Text = "D15";
            this.btnD15.UseVisualStyleBackColor = false;
            this.btnD15.Click += new System.EventHandler(this.btnD15_Click);
            // 
            // btnE1
            // 
            this.btnE1.BackColor = System.Drawing.Color.Lime;
            this.btnE1.Location = new System.Drawing.Point(984, 414);
            this.btnE1.Name = "btnE1";
            this.btnE1.Size = new System.Drawing.Size(30, 19);
            this.btnE1.TabIndex = 61;
            this.btnE1.Text = "E1";
            this.btnE1.UseVisualStyleBackColor = false;
            this.btnE1.Click += new System.EventHandler(this.btnE1_Click);
            // 
            // btnE2
            // 
            this.btnE2.BackColor = System.Drawing.Color.Lime;
            this.btnE2.Location = new System.Drawing.Point(939, 414);
            this.btnE2.Name = "btnE2";
            this.btnE2.Size = new System.Drawing.Size(30, 19);
            this.btnE2.TabIndex = 62;
            this.btnE2.Text = "E2";
            this.btnE2.UseVisualStyleBackColor = false;
            this.btnE2.Click += new System.EventHandler(this.btnE2_Click);
            // 
            // btnE3
            // 
            this.btnE3.BackColor = System.Drawing.Color.Lime;
            this.btnE3.Location = new System.Drawing.Point(890, 414);
            this.btnE3.Name = "btnE3";
            this.btnE3.Size = new System.Drawing.Size(30, 19);
            this.btnE3.TabIndex = 63;
            this.btnE3.Text = "E3";
            this.btnE3.UseVisualStyleBackColor = false;
            this.btnE3.Click += new System.EventHandler(this.btnE3_Click);
            // 
            // btnE4
            // 
            this.btnE4.BackColor = System.Drawing.Color.Lime;
            this.btnE4.Location = new System.Drawing.Point(843, 414);
            this.btnE4.Name = "btnE4";
            this.btnE4.Size = new System.Drawing.Size(30, 19);
            this.btnE4.TabIndex = 64;
            this.btnE4.Text = "E4";
            this.btnE4.UseVisualStyleBackColor = false;
            this.btnE4.Click += new System.EventHandler(this.btnE4_Click);
            // 
            // btnE5
            // 
            this.btnE5.BackColor = System.Drawing.Color.Lime;
            this.btnE5.Location = new System.Drawing.Point(794, 414);
            this.btnE5.Name = "btnE5";
            this.btnE5.Size = new System.Drawing.Size(30, 19);
            this.btnE5.TabIndex = 65;
            this.btnE5.Text = "E5";
            this.btnE5.UseVisualStyleBackColor = false;
            this.btnE5.Click += new System.EventHandler(this.btnE5_Click);
            // 
            // btnE6
            // 
            this.btnE6.BackColor = System.Drawing.Color.Lime;
            this.btnE6.Location = new System.Drawing.Point(748, 414);
            this.btnE6.Name = "btnE6";
            this.btnE6.Size = new System.Drawing.Size(30, 19);
            this.btnE6.TabIndex = 66;
            this.btnE6.Text = "E6";
            this.btnE6.UseVisualStyleBackColor = false;
            this.btnE6.Click += new System.EventHandler(this.btnE6_Click);
            // 
            // btnE7
            // 
            this.btnE7.BackColor = System.Drawing.Color.Lime;
            this.btnE7.Location = new System.Drawing.Point(701, 414);
            this.btnE7.Name = "btnE7";
            this.btnE7.Size = new System.Drawing.Size(30, 19);
            this.btnE7.TabIndex = 67;
            this.btnE7.Text = "E7";
            this.btnE7.UseVisualStyleBackColor = false;
            this.btnE7.Click += new System.EventHandler(this.btnE7_Click);
            // 
            // btnE8
            // 
            this.btnE8.BackColor = System.Drawing.Color.Lime;
            this.btnE8.Location = new System.Drawing.Point(655, 414);
            this.btnE8.Name = "btnE8";
            this.btnE8.Size = new System.Drawing.Size(30, 19);
            this.btnE8.TabIndex = 68;
            this.btnE8.Text = "E8";
            this.btnE8.UseVisualStyleBackColor = false;
            this.btnE8.Click += new System.EventHandler(this.btnE8_Click);
            // 
            // btnE9
            // 
            this.btnE9.BackColor = System.Drawing.Color.Lime;
            this.btnE9.Location = new System.Drawing.Point(607, 414);
            this.btnE9.Name = "btnE9";
            this.btnE9.Size = new System.Drawing.Size(30, 19);
            this.btnE9.TabIndex = 69;
            this.btnE9.Text = "E9";
            this.btnE9.UseVisualStyleBackColor = false;
            this.btnE9.Click += new System.EventHandler(this.btnE9_Click);
            // 
            // btnE10
            // 
            this.btnE10.BackColor = System.Drawing.Color.Lime;
            this.btnE10.Location = new System.Drawing.Point(556, 414);
            this.btnE10.Name = "btnE10";
            this.btnE10.Size = new System.Drawing.Size(35, 19);
            this.btnE10.TabIndex = 70;
            this.btnE10.Text = "E10";
            this.btnE10.UseVisualStyleBackColor = false;
            this.btnE10.Click += new System.EventHandler(this.btnE10_Click);
            // 
            // btnE11
            // 
            this.btnE11.BackColor = System.Drawing.Color.Lime;
            this.btnE11.Location = new System.Drawing.Point(510, 414);
            this.btnE11.Name = "btnE11";
            this.btnE11.Size = new System.Drawing.Size(40, 19);
            this.btnE11.TabIndex = 71;
            this.btnE11.Text = "E11";
            this.btnE11.UseVisualStyleBackColor = false;
            this.btnE11.Click += new System.EventHandler(this.btnE11_Click);
            // 
            // btnE12
            // 
            this.btnE12.BackColor = System.Drawing.Color.Lime;
            this.btnE12.Location = new System.Drawing.Point(467, 414);
            this.btnE12.Name = "btnE12";
            this.btnE12.Size = new System.Drawing.Size(37, 19);
            this.btnE12.TabIndex = 72;
            this.btnE12.Text = "E12";
            this.btnE12.UseVisualStyleBackColor = false;
            this.btnE12.Click += new System.EventHandler(this.btnE12_Click);
            // 
            // btnE13
            // 
            this.btnE13.BackColor = System.Drawing.Color.Lime;
            this.btnE13.Location = new System.Drawing.Point(421, 414);
            this.btnE13.Name = "btnE13";
            this.btnE13.Size = new System.Drawing.Size(40, 19);
            this.btnE13.TabIndex = 73;
            this.btnE13.Text = "E13";
            this.btnE13.UseVisualStyleBackColor = false;
            this.btnE13.Click += new System.EventHandler(this.btnE13_Click);
            // 
            // btnE14
            // 
            this.btnE14.BackColor = System.Drawing.Color.Lime;
            this.btnE14.Location = new System.Drawing.Point(376, 414);
            this.btnE14.Name = "btnE14";
            this.btnE14.Size = new System.Drawing.Size(39, 19);
            this.btnE14.TabIndex = 74;
            this.btnE14.Text = "E14";
            this.btnE14.UseVisualStyleBackColor = false;
            this.btnE14.Click += new System.EventHandler(this.btnE14_Click);
            // 
            // btnE15
            // 
            this.btnE15.BackColor = System.Drawing.Color.Lime;
            this.btnE15.Location = new System.Drawing.Point(320, 414);
            this.btnE15.Name = "btnE15";
            this.btnE15.Size = new System.Drawing.Size(42, 19);
            this.btnE15.TabIndex = 75;
            this.btnE15.Text = "E15";
            this.btnE15.UseVisualStyleBackColor = false;
            this.btnE15.Click += new System.EventHandler(this.btnE15_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 249);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(296, 19);
            this.label3.TabIndex = 76;
            this.label3.Text = "*Asiento B1 solo adultos. Edad (18-74 años)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(26, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(465, 19);
            this.label4.TabIndex = 77;
            this.label4.Text = "Por favor seleccione el asiento que usted desee y que este disponible.";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(26, 494);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(1062, 19);
            this.label5.TabIndex = 78;
            this.label5.Text = "Le recordamos que para reservar su asiento debe de cancelar el 50% del precio del" +
    " vuelo si es pasillo o en la fila de en medio y un 75%si se ubica en la ventanil" +
    "la.";
            // 
            // btnRegresar
            // 
            this.btnRegresar.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegresar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnRegresar.Image = ((System.Drawing.Image)(resources.GetObject("btnRegresar.Image")));
            this.btnRegresar.Location = new System.Drawing.Point(30, 34);
            this.btnRegresar.MaximumSize = new System.Drawing.Size(110, 50);
            this.btnRegresar.Name = "btnRegresar";
            this.btnRegresar.Size = new System.Drawing.Size(110, 50);
            this.btnRegresar.TabIndex = 79;
            this.btnRegresar.Text = "Regresar";
            this.btnRegresar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRegresar.UseVisualStyleBackColor = true;
            // 
            // btnReservar
            // 
            this.btnReservar.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReservar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnReservar.Image = ((System.Drawing.Image)(resources.GetObject("btnReservar.Image")));
            this.btnReservar.Location = new System.Drawing.Point(1146, 294);
            this.btnReservar.MaximumSize = new System.Drawing.Size(110, 50);
            this.btnReservar.Name = "btnReservar";
            this.btnReservar.Size = new System.Drawing.Size(110, 50);
            this.btnReservar.TabIndex = 80;
            this.btnReservar.Text = "Reservar";
            this.btnReservar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnReservar.UseVisualStyleBackColor = true;
            this.btnReservar.Click += new System.EventHandler(this.button2_Click);
            // 
            // seleccionReservacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1329, 643);
            this.Controls.Add(this.btnReservar);
            this.Controls.Add(this.btnRegresar);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnE15);
            this.Controls.Add(this.btnE14);
            this.Controls.Add(this.btnE13);
            this.Controls.Add(this.btnE12);
            this.Controls.Add(this.btnE11);
            this.Controls.Add(this.btnE10);
            this.Controls.Add(this.btnE9);
            this.Controls.Add(this.btnE8);
            this.Controls.Add(this.btnE7);
            this.Controls.Add(this.btnE6);
            this.Controls.Add(this.btnE5);
            this.Controls.Add(this.btnE4);
            this.Controls.Add(this.btnE3);
            this.Controls.Add(this.btnE2);
            this.Controls.Add(this.btnE1);
            this.Controls.Add(this.btnD15);
            this.Controls.Add(this.btnD14);
            this.Controls.Add(this.btnD13);
            this.Controls.Add(this.btnD12);
            this.Controls.Add(this.btnD11);
            this.Controls.Add(this.btnD10);
            this.Controls.Add(this.btnD9);
            this.Controls.Add(this.btnD8);
            this.Controls.Add(this.btnD7);
            this.Controls.Add(this.btnD6);
            this.Controls.Add(this.btnD5);
            this.Controls.Add(this.btnD4);
            this.Controls.Add(this.btnD3);
            this.Controls.Add(this.btnD2);
            this.Controls.Add(this.btnD1);
            this.Controls.Add(this.btnC15);
            this.Controls.Add(this.btnC14);
            this.Controls.Add(this.btnC13);
            this.Controls.Add(this.btnC12);
            this.Controls.Add(this.btnC11);
            this.Controls.Add(this.btnC10);
            this.Controls.Add(this.btnC9);
            this.Controls.Add(this.btnC8);
            this.Controls.Add(this.btnC7);
            this.Controls.Add(this.btnC6);
            this.Controls.Add(this.btnC5);
            this.Controls.Add(this.btnC4);
            this.Controls.Add(this.btnC3);
            this.Controls.Add(this.btnC2);
            this.Controls.Add(this.btnC1);
            this.Controls.Add(this.btnB15);
            this.Controls.Add(this.btnB14);
            this.Controls.Add(this.btnB13);
            this.Controls.Add(this.btnB12);
            this.Controls.Add(this.btnB11);
            this.Controls.Add(this.btnB10);
            this.Controls.Add(this.btnB9);
            this.Controls.Add(this.btnB8);
            this.Controls.Add(this.btnB7);
            this.Controls.Add(this.btnB6);
            this.Controls.Add(this.btnB5);
            this.Controls.Add(this.btnB4);
            this.Controls.Add(this.btnB3);
            this.Controls.Add(this.btnB2);
            this.Controls.Add(this.btnB1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnA15);
            this.Controls.Add(this.btnA14);
            this.Controls.Add(this.btnA13);
            this.Controls.Add(this.btnA12);
            this.Controls.Add(this.btnA11);
            this.Controls.Add(this.btnA10);
            this.Controls.Add(this.btnA9);
            this.Controls.Add(this.btnA8);
            this.Controls.Add(this.btnA7);
            this.Controls.Add(this.btnA6);
            this.Controls.Add(this.btnA5);
            this.Controls.Add(this.btnA4);
            this.Controls.Add(this.btnA3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnA2);
            this.Name = "seleccionReservacion";
            this.Text = "seleccionReservacion";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnA2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnA3;
        private System.Windows.Forms.Button btnA4;
        private System.Windows.Forms.Button btnA5;
        private System.Windows.Forms.Button btnA6;
        private System.Windows.Forms.Button btnA7;
        private System.Windows.Forms.Button btnA8;
        private System.Windows.Forms.Button btnA9;
        private System.Windows.Forms.Button btnA10;
        private System.Windows.Forms.Button btnA11;
        private System.Windows.Forms.Button btnA12;
        private System.Windows.Forms.Button btnA13;
        private System.Windows.Forms.Button btnA14;
        private System.Windows.Forms.Button btnA15;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnB1;
        private System.Windows.Forms.Button btnB2;
        private System.Windows.Forms.Button btnB3;
        private System.Windows.Forms.Button btnB4;
        private System.Windows.Forms.Button btnB5;
        private System.Windows.Forms.Button btnB6;
        private System.Windows.Forms.Button btnB7;
        private System.Windows.Forms.Button btnB8;
        private System.Windows.Forms.Button btnB9;
        private System.Windows.Forms.Button btnB10;
        private System.Windows.Forms.Button btnB11;
        private System.Windows.Forms.Button btnB12;
        private System.Windows.Forms.Button btnB13;
        private System.Windows.Forms.Button btnB14;
        private System.Windows.Forms.Button btnB15;
        private System.Windows.Forms.Button btnC1;
        private System.Windows.Forms.Button btnC2;
        private System.Windows.Forms.Button btnC3;
        private System.Windows.Forms.Button btnC4;
        private System.Windows.Forms.Button btnC5;
        private System.Windows.Forms.Button btnC6;
        private System.Windows.Forms.Button btnC7;
        private System.Windows.Forms.Button btnC8;
        private System.Windows.Forms.Button btnC9;
        private System.Windows.Forms.Button btnC10;
        private System.Windows.Forms.Button btnC11;
        private System.Windows.Forms.Button btnC12;
        private System.Windows.Forms.Button btnC13;
        private System.Windows.Forms.Button btnC14;
        private System.Windows.Forms.Button btnC15;
        private System.Windows.Forms.Button btnD1;
        private System.Windows.Forms.Button btnD2;
        private System.Windows.Forms.Button btnD3;
        private System.Windows.Forms.Button btnD4;
        private System.Windows.Forms.Button btnD5;
        private System.Windows.Forms.Button btnD6;
        private System.Windows.Forms.Button btnD7;
        private System.Windows.Forms.Button btnD8;
        private System.Windows.Forms.Button btnD9;
        private System.Windows.Forms.Button btnD10;
        private System.Windows.Forms.Button btnD11;
        private System.Windows.Forms.Button btnD12;
        private System.Windows.Forms.Button btnD13;
        private System.Windows.Forms.Button btnD14;
        private System.Windows.Forms.Button btnD15;
        private System.Windows.Forms.Button btnE1;
        private System.Windows.Forms.Button btnE2;
        private System.Windows.Forms.Button btnE3;
        private System.Windows.Forms.Button btnE4;
        private System.Windows.Forms.Button btnE5;
        private System.Windows.Forms.Button btnE6;
        private System.Windows.Forms.Button btnE7;
        private System.Windows.Forms.Button btnE8;
        private System.Windows.Forms.Button btnE9;
        private System.Windows.Forms.Button btnE10;
        private System.Windows.Forms.Button btnE11;
        private System.Windows.Forms.Button btnE12;
        private System.Windows.Forms.Button btnE13;
        private System.Windows.Forms.Button btnE14;
        private System.Windows.Forms.Button btnE15;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnRegresar;
        private System.Windows.Forms.Button btnReservar;
    }
}