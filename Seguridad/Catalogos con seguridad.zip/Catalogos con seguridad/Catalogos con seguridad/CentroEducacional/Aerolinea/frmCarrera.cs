﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Navegador;
using ConexionODBC;

namespace Aerolinea
{
    public partial class frmCarrera : Form
    {

        string sCod;
        string estado = "";
        public frmCarrera()
        {
            InitializeComponent();
            btnGuardar.Enabled = false;
            btnCancelar.Enabled = false;
            btnImprimir.Enabled = false;
            funActualizarGrid();
            funSedes();
            funFacultad();
            
        }

        private void funActualizarGrid()
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funconsultarRegistros("carrera", "SELECT carrera.codigoCarrera as Codigo,carrera.nombre as Nombre, facultad.nombre as Facultad, sedes.nombre as Sede from carrera, facultad, sedes WHERE carrera.estado = 'ACTIVO' AND carrera.codigoFacultad = facultad.codigoFacultad AND carrera.codigo_sede = sedes.codigo_sede" , "consulta", grdCarrera);
        }

        string funCortador(string sDato)
        {
            string sCadena = "";
            try
            {
                for (int i = 0; i < sDato.Length; i++)
                {
                    if (sDato.Substring(i, 1) != ".")
                    {
                        sCadena = sCadena + sDato.Substring(i, 1);
                    }
                    else
                    {
                        break;
                    }
                }

            }
            catch
            {
                MessageBox.Show("Error al obtener Codigo", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            return sCadena;
        }

        void funSedes()
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funconsultarRegistrosCombo("codigo_sede", "SELECT concat(codigo_sede, '.', nombre) as Sede from sedes WHERE estado='ACTIVO'", "Sede", cmbSede);

        }

        void funFacultad()
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funconsultarRegistrosCombo("codigoFacultad", "SELECT concat(codigoFacultad, '.', nombre) as Facultad from facultad WHERE estado='ACTIVO'", "Facultad", cmbFacultad);

        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funactivarDesactivarTextbox(txtNombre, true);
            cnegocio.funactivarDesactivarCombobox(cmbFacultad, true);
            cnegocio.funactivarDesactivarCombobox(cmbSede, true);
            btnGuardar.Enabled = true;
            btnCancelar.Enabled = true;
            btnNuevo.Enabled = false;
            btnEditar.Enabled = false;
            btnEliminar.Enabled = false;
            btnRefrescar.Enabled = false;
            btnBuscar.Enabled = false;
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            estado = "editar";
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funactivarDesactivarTextbox(txtNombre, true);
            cnegocio.funactivarDesactivarCombobox(cmbFacultad, true);
            cnegocio.funactivarDesactivarCombobox(cmbSede, true);
            btnGuardar.Enabled = true;
            btnCancelar.Enabled = true;
            btnNuevo.Enabled = false;
            btnEditar.Enabled = false;
            btnEliminar.Enabled = false;
            btnRefrescar.Enabled = false;
            btnBuscar.Enabled = false;
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            estado = "eliminar";
            clasnegocio cn = new clasnegocio();
            cn.funactivarDesactivarTextbox(txtNombre, false);
            btnGuardar.Enabled = true;
            btnCancelar.Enabled = true;
            btnNuevo.Enabled = false;
            btnEditar.Enabled = false;
            btnEliminar.Enabled = false;
            btnRefrescar.Enabled = false;
            btnBuscar.Enabled = false;
            btnAnterior.Enabled = false;
            btnIrPrimero.Enabled = false;
            btnSiguiente.Enabled = false;
            btnIrUltimo.Enabled = false;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            clasnegocio cn = new clasnegocio();
            Boolean bPermiso = true;
            txtFacultad.Text = funCortador(cmbFacultad.Text);
            txtSede.Text = funCortador(cmbSede.Text);

            if (estado.Equals("editar"))
            {

                TextBox[] aDatosEdit = { txtNombre, txtFacultad,txtSede };
                string sTabla = "carrera";
                string sCodigo = "codigoCarrera";

                cn.EditarObjetos(sTabla, bPermiso, aDatosEdit, sCod, sCodigo);
                claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Editar", sTabla);


            }
            else if (estado.Equals("eliminar"))
            {
                string sTabla = "carrera";
                string sCampoLlavePrimaria = "codigoCarrera";
                string sCampoEstado = "estado";
                //System.Console.WriteLine("----" + sCod);
                cn.funeliminarRegistro(sTabla, sCod, sCampoLlavePrimaria, sCampoEstado);
                claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Eliminar", sTabla);
            }
            else if (estado.Equals(""))
            {
                TextBox[] aDatos = { txtNombre, txtEstado, txtFacultad, txtSede };
                string sTabla = "carrera";
                cn.AsignarObjetos(sTabla, bPermiso, aDatos);
                claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Insertar", sTabla);
            }

            estado = "";
            txtNombre.Clear();
            cmbFacultad.SelectedIndex = -1;
            cmbSede.SelectedIndex = -1;
            cn.funactivarDesactivarTextbox(txtNombre, false);
            cn.funactivarDesactivarCombobox(cmbFacultad, false);
            cn.funactivarDesactivarCombobox(cmbSede, false);
            btnGuardar.Enabled = false;
            btnCancelar.Enabled = false;
            btnImprimir.Enabled = false;
            btnNuevo.Enabled = true;
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
            btnRefrescar.Enabled = true;
            btnBuscar.Enabled = true;
            btnAnterior.Enabled = true;
            btnIrPrimero.Enabled = true;
            btnSiguiente.Enabled = true;
            btnIrUltimo.Enabled = true;
            funActualizarGrid();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            clasnegocio cn = new clasnegocio();

            cn.funactivarDesactivarTextbox(txtNombre, false);
            cn.funactivarDesactivarCombobox(cmbFacultad, false);
            cn.funactivarDesactivarCombobox(cmbSede, false);
            txtBuscar.Visible = false;
            lblBuscar.Visible = false;
            lblNombre.Visible = true;
            txtNombre.Visible = true;
            lblFacultad.Visible = true;
            cmbFacultad.Visible = true;
            lblSede.Visible = true;
            cmbSede.Visible = true;
            txtNombre.Clear();
            txtBuscar.Clear();


            btnGuardar.Enabled = false;
            btnCancelar.Enabled = false;
            btnImprimir.Enabled = false;
            btnNuevo.Enabled = true;
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
            btnRefrescar.Enabled = true;
            btnBuscar.Enabled = true;
            btnAnterior.Enabled = true;
            btnIrPrimero.Enabled = true;
            btnSiguiente.Enabled = true;
            btnIrUltimo.Enabled = true;
        }

        private void btnRefrescar_Click(object sender, EventArgs e)
        {
            funActualizarGrid();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            txtBuscar.Visible = true;
            lblBuscar.Visible = true;
            lblNombre.Visible = false;
            txtNombre.Visible = false;
            lblFacultad.Visible = false;
            cmbFacultad.Visible = false;
            lblSede.Visible = false;
            cmbSede.Visible = false;

            btnGuardar.Enabled = false;
            btnCancelar.Enabled = true;
            btnNuevo.Enabled = false;
            btnEditar.Enabled = false;
            btnEliminar.Enabled = false;
            btnRefrescar.Enabled = false;
            btnBuscar.Enabled = false;
            claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Busqueda", "carrera");
        }

        private void txtBuscar_KeyUp(object sender, KeyEventArgs e)
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funconsultarRegistros("carrera"," SELECT carrera.codigoCarrera as Codigo,carrera.nombre as Nombre, facultad.nombre as Facultad, sedes.nombre as Sede from carrera, facultad, sedes WHERE carrera.estado = 'ACTIVO' AND carrera.codigoFacultad = facultad.codigoFacultad AND carrera.codigo_sede = sedes.codigo_sede AND carrera.nombre LIKE '" + txtBuscar.Text + "%'", "consulta", grdCarrera);
        }

        private void grdCarrera_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (estado.Equals("editar"))
            {
                sCod = grdCarrera.Rows[grdCarrera.CurrentCell.RowIndex].Cells[0].Value.ToString();
                txtNombre.Text = grdCarrera.Rows[grdCarrera.CurrentCell.RowIndex].Cells[1].Value.ToString();


            } if (estado.Equals("eliminar"))
            {
                sCod = grdCarrera.Rows[grdCarrera.CurrentCell.RowIndex].Cells[0].Value.ToString();
            }
        }

        private void btnIrPrimero_Click(object sender, EventArgs e)
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funPrimero(grdCarrera);
        }

        private void btnAnterior_Click(object sender, EventArgs e)
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funAnterior(grdCarrera);
        }

        private void btnSiguiente_Click(object sender, EventArgs e)
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funSiguiente(grdCarrera);
        }

        private void btnIrUltimo_Click(object sender, EventArgs e)
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funUltimo(grdCarrera);
        }
    }
}
