﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Navegador;

namespace Aerolinea
{
    public partial class frmPensum : Form
    {
        string sCod;
        string estado = "";
        public frmPensum()
        {
            InitializeComponent();
            btnGuardar.Enabled = false;
            btnCancelar.Enabled = false;
            btnImprimir.Enabled = false;
            funActualizarGrid();
            funCarrera();

        }

        private void funActualizarGrid()
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funconsultarRegistros("pensum", "SELECT pensum.codigo_pensum as Codigo, pensum.ano as Año ,carrera.nombre as Nombre  from pensum, carrera WHERE pensum.estado ='ACTIVO' AND pensum.codigoCarrera = carrera.codigoCarrera", "consulta", grdPensum);
        }

        string funCortador(string sDato)
        {
            string sCadena = "";
            try
            {
                for (int i = 0; i < sDato.Length; i++)
                {
                    if (sDato.Substring(i, 1) != ".")
                    {
                        sCadena = sCadena + sDato.Substring(i, 1);
                    }
                    else
                    {
                        break;
                    }
                }

            }
            catch
            {
                MessageBox.Show("Error al obtener Codigo", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            return sCadena;
        }

        void funCarrera()
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funconsultarRegistrosCombo("codigoCarrera", "SELECT concat(codigoCarrera, '.', nombre) as Carrera from carrera WHERE estado='ACTIVO'", "Carrera", cmbCarrera);
            //cnegocio.funconsultarRegistrosCombo("codigoCarrera", "SELECT concat(codigoCarrera, '.', nombre) as Carrera from carrera WHERE estado='ACTIVO'", "Carrera", cmbBuscar);

        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funactivarDesactivarTextbox(txtAno, true);
            cnegocio.funactivarDesactivarCombobox(cmbCarrera, true);
            btnGuardar.Enabled = true;
            btnCancelar.Enabled = true;
            btnNuevo.Enabled = false;
            btnEditar.Enabled = false;
            btnEliminar.Enabled = false;
            btnRefrescar.Enabled = false;
            btnBuscar.Enabled = false;
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            estado = "editar";
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funactivarDesactivarTextbox(txtAno, true);
            cnegocio.funactivarDesactivarCombobox(cmbCarrera, true);
            btnGuardar.Enabled = true;
            btnCancelar.Enabled = true;
            btnNuevo.Enabled = false;
            btnEditar.Enabled = false;
            btnEliminar.Enabled = false;
            btnRefrescar.Enabled = false;
            btnBuscar.Enabled = false;
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            estado = "eliminar";
            clasnegocio cn = new clasnegocio();
            cn.funactivarDesactivarTextbox(txtAno, false);
            cn.funactivarDesactivarCombobox(cmbCarrera, false);
            btnGuardar.Enabled = true;
            btnCancelar.Enabled = true;
            btnNuevo.Enabled = false;
            btnEditar.Enabled = false;
            btnEliminar.Enabled = false;
            btnRefrescar.Enabled = false;
            btnBuscar.Enabled = false;
            btnAnterior.Enabled = false;
            btnIrPrimero.Enabled = false;
            btnSiguiente.Enabled = false;
            btnIrUltimo.Enabled = false;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            clasnegocio cn = new clasnegocio();
            Boolean bPermiso = true;
            txtCarrera.Text = funCortador(cmbCarrera.Text);

            if (estado.Equals("editar"))
            {

                TextBox[] aDatosEdit = { txtAno, txtCarrera };
                string sTabla = "pensum";
                string sCodigo = "codigo_pensum";

                cn.EditarObjetos(sTabla, bPermiso, aDatosEdit, sCod, sCodigo);
                claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Editar", sTabla);


            }
            else if (estado.Equals("eliminar"))
            {
                string sTabla = "pensum";
                string sCampoLlavePrimaria = "codigo_pensum";
                string sCampoEstado = "estado";
                //System.Console.WriteLine("----" + sCod);
                cn.funeliminarRegistro(sTabla, sCod, sCampoLlavePrimaria, sCampoEstado);
                claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Eliminar", sTabla);
            }
            else if (estado.Equals(""))
            {
                TextBox[] aDatos = { txtAno, txtEstado, txtCarrera};
                string sTabla = "pensum";
                cn.AsignarObjetos(sTabla, bPermiso, aDatos);
                claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Insertar", sTabla);
            }

            estado = "";
            txtAno.Clear();
            cmbCarrera.SelectedIndex = -1;
            cn.funactivarDesactivarTextbox(txtAno, false);
            cn.funactivarDesactivarCombobox(cmbCarrera, false);
            btnGuardar.Enabled = false;
            btnCancelar.Enabled = false;
            btnImprimir.Enabled = false;
            btnNuevo.Enabled = true;
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
            btnRefrescar.Enabled = true;
            btnBuscar.Enabled = true;
            btnAnterior.Enabled = true;
            btnIrPrimero.Enabled = true;
            btnSiguiente.Enabled = true;
            btnIrUltimo.Enabled = true;
            funActualizarGrid();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            clasnegocio cn = new clasnegocio();

            cn.funactivarDesactivarTextbox(txtAno, false);
            cn.funactivarDesactivarCombobox(cmbCarrera, false);
            cmbBuscar.Visible = false;
            lblBuscar.Visible = false;
            lblAno.Visible = true;
            txtAno.Visible = true;
            lblCarrera.Visible = true;
            cmbCarrera.Visible = true;
            txtAno.Clear();
            //txtBuscar.Clear();


            btnGuardar.Enabled = false;
            btnCancelar.Enabled = false;
            btnImprimir.Enabled = false;
            btnNuevo.Enabled = true;
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
            btnRefrescar.Enabled = true;
            btnBuscar.Enabled = true;
            btnAnterior.Enabled = true;
            btnIrPrimero.Enabled = true;
            btnSiguiente.Enabled = true;
            btnIrUltimo.Enabled = true;
        }

        private void btnRefrescar_Click(object sender, EventArgs e)
        {
            funActualizarGrid();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            cmbBuscar.Visible = true;
            lblBuscar.Visible = true;
            lblAno.Visible = false;
            txtAno.Visible = false;
            lblCarrera.Visible = false;
            cmbCarrera.Visible = false;

            btnGuardar.Enabled = false;
            btnCancelar.Enabled = true;
            btnNuevo.Enabled = false;
            btnEditar.Enabled = false;
            btnEliminar.Enabled = false;
            btnRefrescar.Enabled = false;
            btnBuscar.Enabled = false;
            claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Busqueda", "pensum");
        }

        private void grdPensum_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (estado.Equals("editar"))
            {
                sCod = grdPensum.Rows[grdPensum.CurrentCell.RowIndex].Cells[0].Value.ToString();
                txtAno.Text = grdPensum.Rows[grdPensum.CurrentCell.RowIndex].Cells[1].Value.ToString();


            } if (estado.Equals("eliminar"))
            {
                sCod = grdPensum.Rows[grdPensum.CurrentCell.RowIndex].Cells[0].Value.ToString();
            }
        }

        private void btnIrPrimero_Click(object sender, EventArgs e)
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funPrimero(grdPensum);
        }

        private void btnAnterior_Click(object sender, EventArgs e)
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funAnterior(grdPensum);
        }

        private void btnSiguiente_Click(object sender, EventArgs e)
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funSiguiente(grdPensum);
        }

        private void btnIrUltimo_Click(object sender, EventArgs e)
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funUltimo(grdPensum);
        }

        private void cmbBuscar_SelectedIndexChanged(object sender, EventArgs e)
        {
            //string sCodCarrera = funCortador(cmbBuscar.Text);
            //clasnegocio cnegocio = new clasnegocio();
            //cnegocio.funconsultarRegistros("pensum", "SELECT pensum.codigo_pensum as Codigo, pensum.ano as Año ,carrera.nombre as Nombre  from pensum, carrera WHERE pensum.estado ='ACTIVO' AND pensum.codigoCarrera = carrera.codigoCarrera AND codigoCarrera ='"+sCodCarrera+"'", "consulta", grdPensum);
        }
    }
}
