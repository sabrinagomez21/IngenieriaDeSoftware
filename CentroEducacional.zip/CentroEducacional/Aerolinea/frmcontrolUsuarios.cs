﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data;
using Navegador;
using ConexionODBC;

namespace Aerolinea
{
    public partial class frmcontrolUsuarios : Form
    {
        public frmcontrolUsuarios()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
        
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void labelUser_Click(object sender, EventArgs e)
        {

        }
        private void funLlenarComboPersona()
        {
            /*MessageBox.Show("entrando a llenar combo");
            string squery = "SELECT codigo_persona, nombre FROM ce2016.PERSONA";
            MySqlCommand cmdc = new MySqlCommand(squery, clasconexion.funobtenerConexion());
            DataTable dtDatos = new DataTable();
            MySqlDataAdapter mdaDatos = new MySqlDataAdapter(squery, clasconexion.funobtenerConexion());
            mdaDatos.Fill(dtDatos);
            cmbseleccionarpersona.ValueMember = "codigo_persona";
            cmbseleccionarpersona.DisplayMember = "nombre";
            cmbseleccionarpersona.DataSource = dtDatos;
            clasconexion.funobtenerConexion().Close();*/
        }
        private void frmControlUsuarios_Load(object sender, EventArgs e)
        {
            funconsultarUsuario();
            funLlenarComboTipoUsuario();
            funLlenarComboPersona();
            funllenarComboEliminarUsuario();
            funLlenarComboPersona();
            //funbuscarUsuario();
        }
    private void btnGuardarUsuario_Click(object sender, EventArgs e)
        {
            
            clasnegocio cn = new clasnegocio();
            Boolean bPermiso = true;
            string sTabla = "jornada";
            TextBox[] a = { txtNombre };
            cn.AsignarObjetos(sTabla, bPermiso, a);
            
        /*try
            {
                int ifilas;
                int iCodigoUsuario;
                using (clasconexion.funobtenerConexion())
                {
                    string squery = "SELECT COUNT(*) As Cant FROM ce2016.USUARIO ";
                    MySqlCommand cmd = new MySqlCommand(squery, clasconexion.funobtenerConexion());
                    ifilas = Convert.ToInt32(cmd.ExecuteScalar());
                    iCodigoUsuario = ifilas + 1;
                    clasconexion.funobtenerConexion().Close();
                }
                using (clasconexion.funobtenerConexion())
                {
                    string sInsertarUsuario = "INSERT INTO ce2016.USUARIO  (codigo_usuario, nombre_usuario, apellido, user, password_usuario,estado, codigo_rol, codigo_persona )values(" + iCodigoUsuario + ",'" + txtNombre.Text + "','" + txtApellido.Text + "','" + txtUser.Text + "','" + txtPassword.Text + "','" + "ACTIVO" + "','" + cmbSeleccionartipo.SelectedValue + "','" + cmbseleccionarpersona.SelectedValue + "')";
                    MySqlCommand cmd2 = new MySqlCommand(sInsertarUsuario,  clasconexion.funobtenerConexion());
                    MySqlDataReader MyReader;
                    MyReader = cmd2.ExecuteReader();
                    MessageBox.Show("USUARIO REGISTRADO");
                    //INGRESO BITACORA 
                    claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Ingreso Usuario", "USUARIO");
                    //FIN iNGRESO bITACORA
                    clasconexion.funobtenerConexion().Close();
                    
                    funlimpiar();
                    //funconsultarUsuario();
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }*/
        }
        private void funlimpiar()
        {
            txtNombre.Text = "";
            txtApellido.Text = "";
            txtUser.Text = "";
            txtPassword.Text = "";
        }
        private void dataGridViewUsuarios_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void funconsultarUsuario()
        {
            /*using (clasconexion.funobtenerConexion())
            {
                string squery = "SELECT codigo_usuario as CodigoUsuario, nombre_usuario as NombreUsuario, apellido as ApellidoUsuario, user as Usuario, password_usuario as Password, codigo_rol as TipoUsuario, estado as Estado from ce2016.USUARIO where estado = 'ACTIVO'";
                MySqlCommand cmdc = new MySqlCommand(squery, clasconexion.funobtenerConexion());
                DataTable dtDatos = new DataTable();
                MySqlDataAdapter mdaDatos = new MySqlDataAdapter(squery, clasconexion.funobtenerConexion());
                mdaDatos.Fill(dtDatos);
                grdUsuarios.DataSource = dtDatos;
                clasconexion.funobtenerConexion().Close();
            }*/
        }
        private void funLlenarComboTipoUsuario() {
            /*using (clasconexion.funobtenerConexion())
            {
               
                string squery = "SELECT codigo_rol, descripcion FROM ce2016.ROL";
                MySqlCommand cmdc = new MySqlCommand(squery, clasconexion.funobtenerConexion());
                DataTable dtDatos = new DataTable();
                MySqlDataAdapter mdaDatos = new MySqlDataAdapter(squery, clasconexion.funobtenerConexion());
                mdaDatos.Fill(dtDatos);
                cmbSeleccionartipo.ValueMember = "codigo_rol";
                cmbSeleccionartipo.DisplayMember = "descripcion";
                cmbSeleccionartipo.DataSource = dtDatos;
                clasconexion.funobtenerConexion().Close();
            }*/
        }
        private void funbuscarUsuario()
        {
            /*using (clasconexion.funobtenerConexion())
            {

                string squeryBuscarUsuario = "SELECT codigo_persona as CodigoUsuario, nombre_usuario as NombreUsuario,apellido as ApellidoUsuario, user as Usuario,password_usuario as Password, codigo_rol as TipoUsuario,estado as EstadoUsuario FROM ce2016.USUARIO  where nombre_usuario='" + txtbusquedaUsuario.Text +"'";
                MySqlCommand cmdc = new MySqlCommand(squeryBuscarUsuario, clasconexion.funobtenerConexion());
                DataTable dtDat = new DataTable();
                MySqlDataAdapter mdaDat = new MySqlDataAdapter(squeryBuscarUsuario, clasconexion.funobtenerConexion());
                mdaDat.Fill(dtDat);
                grdUsuarios.DataSource = dtDat;
                //INGRESO A BITACORA
                claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Busco Usuario", "MaUsuario");
                //FIN INGRESO BITACORA
                clasconexion.funobtenerConexion().Close();

            }*/
        }
        private void funllenarComboEliminarUsuario()
        {
            /*using (clasconexion.funobtenerConexion())
            {
                string squery = "SELECT codigo_persona, user FROM ce2016.USUARIO where estado='ACTIVO'";
                MySqlCommand cmdc = new MySqlCommand(squery, clasconexion.funobtenerConexion());
                DataTable dtDatos = new DataTable();
                MySqlDataAdapter mdaDatos = new MySqlDataAdapter(squery, clasconexion.funobtenerConexion());
                mdaDatos.Fill(dtDatos);
                cmbeliminarUsuario.ValueMember = "codigo_persona";
                cmbeliminarUsuario.DisplayMember = "user";
                cmbeliminarUsuario.DataSource = dtDatos;
                clasconexion.funobtenerConexion().Close();
            }*/
        }
        private void funeliminarUsuario()
        {
            /*using (clasconexion.funobtenerConexion())
            {
                try
                {
                    //string sfechaNacimiento = dtpasajero.Value.ToShortDateString();
                    //MessageBox.Show(sfechaNacimiento);
                    string seliminarUsuario = "UPDATE ce2016.USUARIO set estado = 'INACTIVO' where codigo_persona = '" + cmbeliminarUsuario.SelectedValue + "'"; 
                    MySqlCommand cmd2 = new MySqlCommand(seliminarUsuario, clasconexion.funobtenerConexion());
                    cmd2.ExecuteNonQuery();
                    //INGRESO BITACORA
                    claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Elimino Usuario", "Usuario");
                    //FIN INGRESO BITACORA
                    clasconexion.funobtenerConexion().Close();
                    funconsultarUsuario();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }*/
        }
 
        private void cmbSeleccionartipo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnBuscarUsuario_Click(object sender, EventArgs e)
        {
            funbuscarUsuario();
        }

        private void btnEliminarUsuario_Click(object sender, EventArgs e)
        {
            funeliminarUsuario();
            funllenarComboEliminarUsuario();
        }

        private void sALIRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnModificarUsuario_Click(object sender, EventArgs e)
        {
            this.Close();
            frmmodificarUsuario modificar = new frmmodificarUsuario();
            modificar.Show();
        }
        private void rEFRESCARToolStripMenuItem_Click(object sender, EventArgs e)
        {
            funconsultarUsuario();
            funllenarComboEliminarUsuario();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
    }
}
    