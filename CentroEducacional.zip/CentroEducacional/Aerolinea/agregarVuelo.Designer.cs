﻿namespace Aerolinea
{
    partial class agregarVuelo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(agregarVuelo));
            this.grdVuelo = new System.Windows.Forms.DataGridView();
            this.txtLlegadaVuelo = new System.Windows.Forms.TextBox();
            this.txtHoraDespegue = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.dtFechaVuelo = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.txtDestino = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtOrigen = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtNoFilas = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtNoAsientos = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtCodVuelo = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCodAvion = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbTipoAvion = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnMenu = new System.Windows.Forms.Button();
            this.btnGuardarVuelo = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.grdVuelo)).BeginInit();
            this.SuspendLayout();
            // 
            // grdVuelo
            // 
            this.grdVuelo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdVuelo.Location = new System.Drawing.Point(31, 283);
            this.grdVuelo.Name = "grdVuelo";
            this.grdVuelo.Size = new System.Drawing.Size(526, 115);
            this.grdVuelo.TabIndex = 125;
            // 
            // txtLlegadaVuelo
            // 
            this.txtLlegadaVuelo.Location = new System.Drawing.Point(356, 235);
            this.txtLlegadaVuelo.Name = "txtLlegadaVuelo";
            this.txtLlegadaVuelo.Size = new System.Drawing.Size(80, 20);
            this.txtLlegadaVuelo.TabIndex = 120;
            // 
            // txtHoraDespegue
            // 
            this.txtHoraDespegue.Location = new System.Drawing.Point(146, 237);
            this.txtHoraDespegue.Name = "txtHoraDespegue";
            this.txtHoraDespegue.Size = new System.Drawing.Size(81, 20);
            this.txtHoraDespegue.TabIndex = 119;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(255, 236);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(95, 19);
            this.label11.TabIndex = 118;
            this.label11.Text = "Hora Llegada";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(27, 236);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(109, 19);
            this.label10.TabIndex = 117;
            this.label10.Text = "Hora Despegue";
            // 
            // dtFechaVuelo
            // 
            this.dtFechaVuelo.Location = new System.Drawing.Point(173, 202);
            this.dtFechaVuelo.Name = "dtFechaVuelo";
            this.dtFechaVuelo.Size = new System.Drawing.Size(200, 20);
            this.dtFechaVuelo.TabIndex = 116;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(22, 202);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(114, 19);
            this.label9.TabIndex = 115;
            this.label9.Text = "Fecha Del Vuelo";
            // 
            // txtDestino
            // 
            this.txtDestino.Location = new System.Drawing.Point(348, 164);
            this.txtDestino.Name = "txtDestino";
            this.txtDestino.Size = new System.Drawing.Size(100, 20);
            this.txtDestino.TabIndex = 114;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(45, 167);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 19);
            this.label8.TabIndex = 113;
            this.label8.Text = "Origen";
            // 
            // txtOrigen
            // 
            this.txtOrigen.Location = new System.Drawing.Point(137, 164);
            this.txtOrigen.Name = "txtOrigen";
            this.txtOrigen.Size = new System.Drawing.Size(100, 20);
            this.txtOrigen.TabIndex = 112;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(267, 167);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 19);
            this.label7.TabIndex = 111;
            this.label7.Text = "Destino";
            // 
            // txtNoFilas
            // 
            this.txtNoFilas.Location = new System.Drawing.Point(348, 131);
            this.txtNoFilas.Name = "txtNoFilas";
            this.txtNoFilas.Size = new System.Drawing.Size(100, 20);
            this.txtNoFilas.TabIndex = 110;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(267, 135);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 19);
            this.label6.TabIndex = 109;
            this.label6.Text = "No. Filas";
            // 
            // txtNoAsientos
            // 
            this.txtNoAsientos.Location = new System.Drawing.Point(137, 134);
            this.txtNoAsientos.Name = "txtNoAsientos";
            this.txtNoAsientos.Size = new System.Drawing.Size(100, 20);
            this.txtNoAsientos.TabIndex = 108;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(21, 132);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 19);
            this.label5.TabIndex = 107;
            this.label5.Text = "No. Asientos";
            // 
            // txtCodVuelo
            // 
            this.txtCodVuelo.Location = new System.Drawing.Point(405, 95);
            this.txtCodVuelo.Name = "txtCodVuelo";
            this.txtCodVuelo.Size = new System.Drawing.Size(100, 20);
            this.txtCodVuelo.TabIndex = 106;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(267, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(117, 19);
            this.label4.TabIndex = 105;
            this.label4.Text = "Codigo De Vuelo";
            // 
            // txtCodAvion
            // 
            this.txtCodAvion.Location = new System.Drawing.Point(146, 97);
            this.txtCodAvion.Name = "txtCodAvion";
            this.txtCodAvion.Size = new System.Drawing.Size(100, 20);
            this.txtCodAvion.TabIndex = 104;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(21, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 19);
            this.label3.TabIndex = 103;
            this.label3.Text = "Codigo de Avion";
            // 
            // cmbTipoAvion
            // 
            this.cmbTipoAvion.FormattingEnabled = true;
            this.cmbTipoAvion.Location = new System.Drawing.Point(146, 60);
            this.cmbTipoAvion.Name = "cmbTipoAvion";
            this.cmbTipoAvion.Size = new System.Drawing.Size(121, 21);
            this.cmbTipoAvion.TabIndex = 102;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(21, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 19);
            this.label2.TabIndex = 101;
            this.label2.Text = "Tipo De Avion";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(235, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(172, 23);
            this.label1.TabIndex = 100;
            this.label1.Text = "Asignacion de Vuelos";
            // 
            // btnMenu
            // 
            this.btnMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenu.Image = ((System.Drawing.Image)(resources.GetObject("btnMenu.Image")));
            this.btnMenu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMenu.Location = new System.Drawing.Point(12, 6);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(110, 50);
            this.btnMenu.TabIndex = 126;
            this.btnMenu.Text = "Menu";
            this.btnMenu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnMenu.UseVisualStyleBackColor = true;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // btnGuardarVuelo
            // 
            this.btnGuardarVuelo.Image = ((System.Drawing.Image)(resources.GetObject("btnGuardarVuelo.Image")));
            this.btnGuardarVuelo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGuardarVuelo.Location = new System.Drawing.Point(239, 413);
            this.btnGuardarVuelo.Name = "btnGuardarVuelo";
            this.btnGuardarVuelo.Size = new System.Drawing.Size(100, 50);
            this.btnGuardarVuelo.TabIndex = 121;
            this.btnGuardarVuelo.Text = "Guardar";
            this.btnGuardarVuelo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnGuardarVuelo.UseVisualStyleBackColor = true;
            // 
            // agregarVuelo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(579, 475);
            this.Controls.Add(this.btnMenu);
            this.Controls.Add(this.btnGuardarVuelo);
            this.Controls.Add(this.grdVuelo);
            this.Controls.Add(this.txtLlegadaVuelo);
            this.Controls.Add(this.txtHoraDespegue);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.dtFechaVuelo);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtDestino);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtOrigen);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtNoFilas);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtNoAsientos);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtCodVuelo);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtCodAvion);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmbTipoAvion);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(595, 514);
            this.MinimumSize = new System.Drawing.Size(595, 514);
            this.Name = "agregarVuelo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registrar Vuelo";
            ((System.ComponentModel.ISupportInitialize)(this.grdVuelo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGuardarVuelo;
        private System.Windows.Forms.DataGridView grdVuelo;
        private System.Windows.Forms.TextBox txtLlegadaVuelo;
        private System.Windows.Forms.TextBox txtHoraDespegue;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker dtFechaVuelo;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtDestino;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtOrigen;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtNoFilas;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtNoAsientos;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtCodVuelo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtCodAvion;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbTipoAvion;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnMenu;
    }
}