﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aerolinea
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (claseUsuario.Autentificar(txtUser.Text, txtPass.Text) == true)
            {
                //VALIDACIÓN DE USUARIO ADMINISTRADOR
                if (claseUsuario.user(txtUser.Text, txtPass.Text).Equals("Admin"))
                {
                    this.Hide();
                    frmMenu Menu = new frmMenu();
                    Menu.Show();
                    Menu.toolStripStatusLabel2.Text = "Usuario: " + txtUser.Text;
                    Menu.toolStripStatusLabel.Text = DateTime.Now.ToString();

                    claseUsuario.varibaleUsuario = txtUser.Text;
                    claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Ingreso al Sistema", "Administrador");
                    MessageBox.Show("Bienvenid@:  " + claseUsuario.user(txtUser.Text, txtPass.Text) + ":" + claseUsuario.varibaleUsuario);
                }

                //VALIDACIÓN DE USUARIO NORMAL (PERMISOS BÁSICOS DE INSERTAR Y CONSULTAR)
                else if (claseUsuario.user(txtUser.Text, txtPass.Text).Equals("Normal"))
                {
                    this.Hide();
                    /*frmMenu MenuNormal = new frmMenu();
                    MenuNormal.Show();
                    MenuNormal.toolStripStatusLabel2.Text = "Usuario: " + txtUser.Text;
                
                    MenuNormal.uSUARIOSToolStripMenuItem.Enabled = false;
                    MenuNormal.rEPORTESToolStripMenuItem.Enabled = false;
                    MenuNormal.toolStripStatusLabel.Text = DateTime.Now.ToString();*/
                    claseUsuario.varibaleUsuario = txtUser.Text;
                    claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Ingreso al Sistema", "Normal");
                    MessageBox.Show("Bienvenid@:  " + claseUsuario.user(txtUser.Text, txtPass.Text) + ":" + claseUsuario.varibaleUsuario);
                }

                //VALIDACIÓN USUARIO QUE ACCEDE A INFORMACIÓN DE VUELOS
                else if (claseUsuario.user(txtUser.Text, txtPass.Text).Equals("Vuelos"))
                {
                    this.Hide();
                    /*frmMenu MenuVuelos = new frmMenu();
                    MenuVuelos.Show();
                    MenuVuelos.toolStripStatusLabel2.Text = "Usuario: " + txtUser.Text;
                    MenuVuelos.uSUARIOSToolStripMenuItem.Enabled = false;
                  
                    MenuVuelos.rEPORTESToolStripMenuItem.Enabled = false;
                    MenuVuelos.toolStripStatusLabel.Text = DateTime.Now.ToString();*/
                    claseUsuario.varibaleUsuario = txtUser.Text;
                    claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Ingreso al Sistema", "Vuelos");
                    MessageBox.Show("Bienvenid@:  " + claseUsuario.user(txtUser.Text, txtPass.Text) + ":" + claseUsuario.varibaleUsuario);
                }

            }
            else
                MessageBox.Show("Usuario o Password Incorrecto, Si el problema persiste su Usuario esta Inactivo");

            txtUser.Clear();
            txtPass.Clear();
        }
    }
}
